const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--autoplay-policy=no-user-gesture-required','--mute-audio'] });
  const ctx = await browser.newContext({ userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', viewport: {width:1280,height:720} });
  const page = await ctx.newPage();
  const interesting = [];
  page.on('request', r => { const u=r.url(); if(/m3u8|getSources|domain|\.ts(\?|$)|master|playlist|bypass/i.test(u)) interesting.push(r.method()+' '+u); });
  page.on('console', m => { const t=m.text(); if(/m3u8|source|error/i.test(t)) console.log('[console]', t.slice(0,300)); });
  await page.goto('https://megaplay.buzz/stream/s-2/751819/sub', { waitUntil: 'domcontentloaded', timeout: 60000 });
  await page.waitForTimeout(15000);
  console.log('--- INTERESTING REQUESTS ---');
  [...new Set(interesting)].forEach(x => console.log(x));
  const info = await page.evaluate(() => {
    const v = document.querySelector('video');
    return {
      videoFound: !!v,
      src: v ? v.currentSrc || v.src : null,
      duration: v ? v.duration : null,
      currentTime: v ? v.currentTime : null,
      paused: v ? v.paused : null,
      readyState: v ? v.readyState : null,
      videoW: v ? v.videoWidth : null, videoH: v ? v.videoHeight : null,
      tracks: v ? [...v.textTracks].map(t=>({kind:t.kind,label:t.label,mode:t.mode})) : null,
      hasHls: typeof window.Hls,
      jw: typeof window.jwplayer,
      settingsKeys: window.settings ? Object.keys(window.settings) : null
    };
  });
  console.log('--- PAGE STATE ---'); console.log(JSON.stringify(info,null,1));
  await browser.close();
})();
