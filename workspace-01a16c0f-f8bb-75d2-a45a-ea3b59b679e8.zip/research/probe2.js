const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({
    headless: false, channel: undefined,
    args: ['--autoplay-policy=no-user-gesture-required','--disable-blink-features=AutomationControlled','--no-sandbox','--window-size=1280,720']
  });
  const ctx = await browser.newContext({
    userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
    viewport: {width:1280,height:720}
  });
  await ctx.addInitScript(() => { Object.defineProperty(navigator,'webdriver',{get:()=>undefined}); });
  const page = await ctx.newPage();
  const reqs = [];
  page.on('request', r => reqs.push(r.method()+' '+r.url()));
  page.on('console', m => console.log('[console]', m.type(), m.text().slice(0,250)));
  page.on('pageerror', e => console.log('[pageerror]', String(e).slice(0,250)));
  const resp = await page.goto('https://megaplay.buzz/stream/s-2/751819/sub', { waitUntil: 'domcontentloaded', timeout: 60000 });
  console.log('goto status', resp && resp.status());
  await page.waitForTimeout(18000);
  console.log('--- ALL REQUESTS (%d) ---', reqs.length);
  reqs.forEach(x => console.log(x));
  const info = await page.evaluate(() => {
    const v = document.querySelector('video');
    return { title: document.title, bodyLen: document.body ? document.body.innerHTML.length : -1,
      bodySnippet: document.body ? document.body.innerText.slice(0,400) : null,
      videoFound: !!v, src: v?(v.currentSrc||v.src):null, duration: v?v.duration:null,
      paused: v?v.paused:null, readyState: v?v.readyState:null, vw: v?v.videoWidth:null, vh: v?v.videoHeight:null,
      hasHls: typeof window.Hls, jw: typeof window.jwplayer, settings: window.settings||null };
  });
  console.log('--- STATE ---'); console.log(JSON.stringify(info,null,1));
  await browser.close();
})();
