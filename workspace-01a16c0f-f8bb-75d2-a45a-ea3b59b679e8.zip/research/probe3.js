const { chromium } = require('playwright');
const TARGET='https://megaplay.buzz/stream/s-2/751819/sub';
const CASES = [
  { name:'A: defaults + extraHeaders Referer', ctx:{}, hdr:{ 'Referer':'https://megaplay.buzz/' } },
  { name:'B: no UA override, Referer only', ctx:{ userAgent: null }, hdr:{ 'Referer':'https://megaplay.buzz/' } },
  { name:'C: extraHeaders UA+Referer+SecFetchSite', ctx:{}, hdr:{ 'Referer':'https://megaplay.buzz/','User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','Sec-Fetch-Site':'same-origin','Sec-Fetch-Mode':'navigate','Sec-Fetch-Dest':'iframe' } },
  { name:'D: iframe from megaplay host page', ctx:{}, hdr:{}, iframe:true },
];
(async()=>{
  const browser = await chromium.launch({ headless:false, args:['--autoplay-policy=no-user-gesture-required','--disable-blink-features=AutomationControlled','--no-sandbox'] });
  for (const c of CASES){
    try{
      const opts = JSON.parse(JSON.stringify(c.ctx||{}));
      if (c.name.includes('no UA')) delete opts.userAgent;
      const ctx = await browser.newContext(Object.assign({ viewport:{width:1280,height:720} }, c.ctx.userAgent===null?{}:c.ctx));
      const page = await ctx.newPage();
      let title='?';
      if (c.iframe){
        await page.goto('https://megaplay.buzz/', {waitUntil:'domcontentloaded', timeout:30000});
        await page.setContent(`<html><body style="margin:0;background:#000"><iframe src="${TARGET}" style="width:100%;height:100%;border:0" allowfullscreen></iframe></body></html>`);
        await page.waitForTimeout(8000);
        for (const f of page.frames()){ try{ title = f.url().includes('s-2') ? (await f.title()||f.url()) : title; }catch(e){} }
      } else {
        const r = await page.goto(TARGET,{waitUntil:'domcontentloaded',timeout:30000, extraHTTPHeaders:c.hdr||{}});
        await page.waitForTimeout(3000);
        title = await page.title();
        console.log('  status', r&&r.status());
      }
      const vid = await page.evaluate(()=>{const v=document.querySelector('video');return v?{src:(v.currentSrc||v.src).slice(0,120),dur:v.duration,rs:v.readyState,w:v.videoWidth,h:v.videoHeight}:null}).catch(()=>null);
      console.log(`[${c.name}] title="${title}" video=${JSON.stringify(vid)}`);
      await ctx.close();
    }catch(e){ console.log(`[${c.name}] ERROR ${String(e).slice(0,150)}`); }
  }
  await browser.close();
})();
