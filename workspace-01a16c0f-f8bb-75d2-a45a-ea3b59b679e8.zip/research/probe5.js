const { chromium } = require('playwright');
const fs=require('fs');
const EMB='https://megaplay.buzz/stream/s-2/751819/sub';
(async()=>{
  const browser = await chromium.launch({ headless:false, args:['--autoplay-policy=no-user-gesture-required','--disable-blink-features=AutomationControlled','--no-sandbox','--mute-audio'] });
  const ctx = await browser.newContext({ viewport:{width:1280,height:720} });
  const page = await ctx.newPage();
  const m3u8=[];
  page.on('request', r=>{ const u=r.url(); if(/master\.m3u8|index-f\d+\.m3u8/.test(u)) m3u8.push(u); });
  // decrypt domains in a plain page using the same constants
  await page.goto('https://megaplay.buzz/', {waitUntil:'domcontentloaded', timeout:30000});
  const dom = await page.evaluate(async ()=>{
    const KEY="i?LMTAx0Q6,:}\n50U", IV="W0;\n27ToaUpl_P%'c";
    const pad=(s,n)=>{const b=new Uint8Array(n); b.set(new TextEncoder().encode(s).subarray(0,Math.min(n,new TextEncoder().encode(s).length))); return b;};
    const b64u=e=>{let t=String(e).replace(/-/g,'+').replace(/_/g,'/'); const n=t.length%4; if(n) t+="====".slice(n); const a=atob(t); const r=new Uint8Array(a.length); for(let i=0;i<a.length;i++)r[i]=a.charCodeAt(i); return r;};
    const j=await (await fetch('https://megaplay.buzz/domains?h='+Date.now())).json();
    const key=await crypto.subtle.importKey('raw',pad(KEY,32),{name:'AES-CBC'},false,['decrypt']);
    const pt=await crypto.subtle.decrypt({name:'AES-CBC',iv:pad(IV,16)},key,b64u(j.enc));
    return JSON.parse(new TextDecoder().decode(pt));
  }).catch(e=>({err:String(e)}));
  console.log('=== DECRYPTED DOMAINS ==='); console.log(JSON.stringify(dom,null,1));
  // now load embed in iframe and capture m3u8
  await page.setContent(`<html><body style="margin:0;background:#000"><iframe id=f src="${EMB}" style="width:100%;height:100%;border:0" allowfullscreen></iframe></body></html>`);
  await page.waitForTimeout(25000);
  console.log('=== M3U8 URLS ==='); [...new Set(m3u8)].forEach(u=>console.log(u));
  fs.writeFileSync('m3u8_urls.json', JSON.stringify([...new Set(m3u8)],null,1));
  // grab SKP_DATA / intro-outro from player internals
  let f=null; for(const fr of page.frames()) if(fr.url().includes('s-2')) f=fr;
  if(f){
    const x = await f.evaluate(()=>({ intro: document.getElementById('skip-intro-megaplay')?.style.display, outro: document.getElementById('skip-outro-megaplay')?.style.display, dur: document.querySelector('video')?.duration })).catch(e=>String(e));
    console.log('=== player skip buttons ===', JSON.stringify(x));
  }
  await browser.close();
})();
