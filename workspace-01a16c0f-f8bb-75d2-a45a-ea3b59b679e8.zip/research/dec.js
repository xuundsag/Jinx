const crypto=require('crypto');
const KEY="i?LMTAx0Q6,:}\n50U", IV="W0;\n27ToaUpl_P%'c";
function pad(s,n){const b=Buffer.alloc(n); Buffer.from(s,'utf8').copy(b,0,0,Math.min(Buffer.byteLength(s),n)); return b;}
function b64u(s){let t=s.replace(/-/g,'+').replace(/_/g,'/'); t+='='.repeat((4-t.length%4)%4); return Buffer.from(t,'base64');}
const enc=require('fs').readFileSync('domains.json','utf8');
const j=JSON.parse(enc);
const d=crypto.createDecipheriv('aes-256-cbc', pad(KEY,32), pad(IV,16));
d.setAutoPadding(true);
let out=Buffer.concat([d.update(b64u(j.enc)), d.final()]);
console.log(out.toString('utf8'));
