const crypto=require('crypto');
const tok="MTc5Mjc2NTcwMXxhYTM2Y2I1OTY3NDM0ZDgyOTAzMjlkMmUzZGIwODJiZS9iNzMzMTk3NTU5NmQ4ZTI1M2NmOTNiNGZhZGFiNTA5MQ.CfPSiS_t2hfREYE2opeDbNTtWqHevM2bGNeMMtq4rh0";
const [p1,sig]=tok.split('.');
const plain=Buffer.from(p1,'base64').toString('utf8');
console.log('decoded p1:',plain);
const [ts,path]=plain.split('|');
console.log('ts=',ts,'path=',path);
const cid='4e4f', cidu='6ad881fa3257f';
const H=(a,b)=>crypto.createHash(b).update(a).digest('base64url');
const cands={
 'sha256(ts|path+cid)':H(ts+'|'+path+cid,'sha256'),
 'sha256(path+cid)':H(path+cid,'sha256'),
 'sha256(plain+cid)':H(plain+cid,'sha256'),
 'sha256(ts|path+cidu)':H(plain+cidu,'sha256'),
 'sha256(plain+cid+cidu)':H(plain+cid+cidu,'sha256'),
 'sha256(plain+cidu+cid)':H(plain+cidu+cid,'sha256'),
 'sha1(plain+cid)':H(plain+cid,'sha1'),
 'sha1(path+cid)':H(path+cid,'sha1'),
 'md5(plain+cid)':H(plain+cid,'md5'),
 'md5(path+cid)':H(path+cid,'md5'),
 'sha256(cid+plain)':H(cid+plain,'sha256'),
 'sha256(cidu+plain)':H(cidu+plain,'sha256'),
 'sha256(plain+cid).slice43':H(plain+cid,'sha256').slice(0,43),
 'sha256(path).slice43':H(path,'sha256').slice(0,43),
 'sha1(ts+path+cid)':H(ts+path+cid,'sha1'),
};
console.log('TARGET sig:',sig, 'len', sig.length);
for(const [k,v] of Object.entries(cands)) console.log((v===sig?'*** MATCH *** ':'              ')+k+' -> '+v);
