const { chromium } = require('playwright');
const TARGET='https://megaplay.buzz/stream/s-2/751819/sub';
(async()=>{
  const browser = await chromium.launch({ headless:false, args:['--autoplay-policy=no-user-gesture-required','--disable-blink-features=AutomationControlled','--no-sandbox','--mute-audio'] });
  const ctx = await browser.newContext({ viewport:{width:1280,height:720} });
  const page = await ctx.newPage();
  const reqs=[];
  page.on('request', r=>{ const u=r.url(); if(/m3u8|getSources|domain|\.ts($|\?)|playlist|bypass|\.vtt|bust/i.test(u)) reqs.push(r.method()+' '+u); });
  await page.goto('https://megaplay.buzz/', {waitUntil:'domcontentloaded', timeout:30000});
  await page.setContent(`<html><body style="margin:0;background:#000"><iframe id=f src="${TARGET}" style="width:100%;height:100%;border:0" allowfullscreen></iframe></body></html>`);
  await page.waitForTimeout(30000);
  console.log('=== MATCHED REQUESTS ==='); [...new Set(reqs)].forEach(x=>console.log(x));
  let f=null; for(const fr of page.frames()) if(fr.url().includes('s-2')) f=fr;
  if(!f){ console.log('no iframe frame found; frames=', page.frames().map(x=>x.url())); }
  else{
    const st = await f.evaluate(()=>{ const v=document.querySelector('video');
      return { title:document.title, settings:window.settings||null, hasHls:typeof window.Hls, jw:typeof window.jwplayer,
        video: v?{src:(v.currentSrc||v.src),dur:v.duration,ct:v.currentTime,paused:v.paused,rs:v.readyState,w:v.videoWidth,h:v.videoHeight}:null,
        textTracks: v?[...v.textTracks].map(t=>({k:t.kind,l:t.label,m:t.mode})):null,
        bodyCls: document.body.className, playerHtml: (document.getElementById('megaplay-player')||{}).innerHTML?.slice(0,300) };
    }).catch(e=>({err:String(e)}));
    console.log('=== IFRAME STATE ==='); console.log(JSON.stringify(st,null,1));
  }
  await browser.close();
})();
