// The control panel.
//
// It is ONE Discord Container built from Components V2 primitives:
//
//   Container
//     Section            bold title, linked to a Google search, + Thumbnail
//     TextDisplay        Duration / Language / Captions / Status, plus a
//                        resume note when this episode was started before
//     Separator
//     ActionRow          Seek | <<10 | Pause-Resume | >>10 | Skip
//
// The ten second buttons use the guillemets the spec names. They are
// punctuation rather than emoji, so the rest of the panel can stay plain text.
//     ActionRow          Autoplay | Stop
//
// Deliberately absent: no embed, no accent colour, no header, no footer.
//
// Two exports matter here:
//   describePanel() -> a plain JSON object describing the layout. This is what
//                      the snapshot tests compare, so a layout change is caught
//                      even when nobody is looking at Discord.
//   buildPanel()    -> the real discord.js ContainerBuilder, produced from that
//                      same description so the two can never disagree.

import { formatDuration } from './time.js';

export const BTN = Object.freeze({
  SEEK: 'panel:seek',
  BACK10: 'panel:back10',
  TOGGLE: 'panel:toggle',
  FWD10: 'panel:fwd10',
  SKIP: 'panel:skip',
  AUTOPLAY: 'panel:autoplay',
  STOP: 'panel:stop',
});

// The five status markers the spec asks for. Everything else on the panel is
// plain text, so the whole UI reads simply.
const STATUS_GLYPH = {
  playing: '\u{1F7E2}', // green circle
  paused: '\u23F8', // pause
  loading: '\u{1F7E1}', // yellow circle
  error: '\u{1F534}', // red circle
  idle: '\u26AA', // white circle
};

/** Human label for the audio track. */
export function languageLabel(audio) {
  return audio === 'dub' ? 'English (Dub)' : 'Japanese (Sub)';
}

/** One status line, given the current playback snapshot. */
export function statusLine(state, errorMessage) {
  const g = STATUS_GLYPH[state] || STATUS_GLYPH.idle;
  switch (state) {
    case 'playing':
      return `${g} Now playing`;
    case 'paused':
      return `${g} Paused`;
    case 'loading':
      return `${g} Loading`;
    case 'error':
      return `${g} Error: ${errorMessage || 'unknown reason'}`;
    default:
      return `${g} Idle`;
  }
}

/**
 * Build the plain description of the panel.
 *
 * @param {object} s
 * @param {string} s.title        anime title, used for the linked heading
 * @param {number} s.episode      episode number
 * @param {string} s.searchUrl    Google search URL for the heading link
 * @param {string|null} s.logoUrl transparent logo for the Thumbnail accessory
 * @param {number} s.position     current position in seconds
 * @param {number} s.duration     episode length in seconds
 * @param {'sub'|'dub'} s.audio
 * @param {boolean} s.captions
 * @param {string} s.state        one of STATE.*
 * @param {string|null} s.error   error reason when state is 'error'
 * @param {boolean} s.paused      convenience: drives the Pause/Resume label
 */
export function describePanel(s) {
  const paused = s.state === 'paused' || s.paused === true;

  const lines = [
    `Duration: ${formatDuration(s.position || 0)} / ${formatDuration(s.duration || 0)}`,
    `Language: ${languageLabel(s.audio)}`,
    `Captions: ${s.captions ? 'On' : 'Off'}`,
    `Status: ${statusLine(s.state, s.error)}`,
  ];
  // Only shown when there is a real resume point, so the panel does not grow a
  // permanent line that says nothing.
  if (s.resumeFrom > 0 && (s.position || 0) < 5) {
    lines.push(`Resumed from ${formatDuration(s.resumeFrom)}`);
  }
  if (s.episodeCount) {
    lines.push(`Episode ${s.episode} of ${s.episodeCount}`);
  }

  return {
    kind: 'container',
    // No accent colour set on purpose - the spec forbids it.
    accentColor: null,
    header: null,
    footer: null,
    children: [
      {
        kind: 'section',
        accessory: { kind: 'thumbnail', url: s.logoUrl || null },
        components: [
          {
            kind: 'text',
            // Bold markdown title, wrapped in a markdown link to Google.
            content: `**[${s.title} - Episode ${s.episode}](${s.searchUrl})**`,
          },
        ],
      },
      { kind: 'text', content: lines.join('\n') },
      { kind: 'separator', spacing: 'small', divider: true },
      {
        kind: 'row',
        components: [
          { kind: 'button', id: BTN.SEEK, label: 'Seek', style: 'secondary' },
          { kind: 'button', id: BTN.BACK10, label: '\u00AB10', style: 'secondary' },
          {
            kind: 'button',
            id: BTN.TOGGLE,
            label: paused ? 'Resume' : 'Pause',
            style: 'primary',
          },
          { kind: 'button', id: BTN.FWD10, label: '\u00BB10', style: 'secondary' },
          { kind: 'button', id: BTN.SKIP, label: 'Skip', style: 'secondary' },
        ],
      },
      {
        kind: 'row',
        components: [
          {
            kind: 'button',
            id: BTN.AUTOPLAY,
            // The label states the current setting, so pressing it is not a
            // guess about what happens next.
            label: s.autoplay ? 'Autoplay: On' : 'Autoplay: Off',
            style: s.autoplay ? 'primary' : 'secondary',
          },
          { kind: 'button', id: BTN.STOP, label: 'Stop', style: 'danger' },
        ],
      },
    ],
  };
}

/**
 * The seek modal. Discord modals need a custom id plus one text input; we keep
 * the id stable so the controller can route the submit.
 */
export const SEEK_MODAL_ID = 'panel:seek:modal';

export function describeSeekModal(currentPosition) {
  return {
    kind: 'modal',
    customId: SEEK_MODAL_ID,
    title: 'Seek to',
    components: [
      {
        kind: 'row',
        components: [
          {
            kind: 'text-input',
            customId: 'seek_value',
            style: 'short',
            label: 'Position',
            placeholder: 'e.g. 90, 1:30 or 01:02:03',
            required: true,
            // Prefill with the current position so a small edit is enough.
            value: formatDuration(currentPosition || 0),
          },
        ],
      },
    ],
  };
}

/**
 * Turn a description into a ContainerBuilder, given the discord.js builders.
 *
 * Split out from buildPanel so a caller that has already imported discord.js can
 * build panels synchronously. Button handlers run on every click, and an await
 * per click is pointless once the module is loaded.
 */
export function buildContainer(d, builders) {
  const {
    ContainerBuilder,
    SectionBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    ThumbnailBuilder,
    SeparatorSpacingSize,
  } = builders;

  const STYLE = {
    primary: ButtonStyle.Primary,
    secondary: ButtonStyle.Secondary,
    danger: ButtonStyle.Danger,
  };

  const container = new ContainerBuilder();
  // No accent colour is set here on purpose, the spec forbids one.

  for (const child of d.children) {
    if (child.kind === 'section') {
      const text = child.components.map((c) => c.content).join('\n');
      // A Discord Section must carry a button or a thumbnail accessory. With no
      // logo there is nothing to attach, so the title is emitted as a plain
      // TextDisplay rather than an invalid empty Section.
      if (!child.accessory?.url) {
        container.addTextDisplayComponents(new TextDisplayBuilder().setContent(text));
        continue;
      }
      const section = new SectionBuilder();
      section.addTextDisplayComponents(new TextDisplayBuilder().setContent(text));
      section.setThumbnailAccessory(new ThumbnailBuilder().setURL(child.accessory.url));
      container.addSectionComponents(section);
    } else if (child.kind === 'text') {
      container.addTextDisplayComponents(new TextDisplayBuilder().setContent(child.content));
    } else if (child.kind === 'separator') {
      container.addSeparatorComponents(
        new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(child.divider !== false),
      );
    } else if (child.kind === 'row') {
      const row = new ActionRowBuilder();
      for (const b of child.components) {
        row.addComponents(
          new ButtonBuilder().setCustomId(b.id).setLabel(b.label).setStyle(STYLE[b.style] ?? ButtonStyle.Secondary),
        );
      }
      container.addActionRowComponents(row);
    }
  }
  return container;
}

/**
 * Async form: imports discord.js on first use, so unit tests can exercise
 * describePanel without discord.js being installed.
 *
 * @returns {Promise<import('discord.js').ContainerBuilder>}
 */
export async function buildPanel(state) {
  const builders = await import('discord.js');
  return buildContainer(describePanel(state), builders);
}

/** Same for the seek modal. */
export async function buildSeekModal(currentPosition) {
  const { ModalBuilder, ActionRowBuilder, TextInputBuilder, TextInputStyle } = await import('discord.js');
  const d = describeSeekModal(currentPosition);
  const input = d.components[0].components[0];
  const modal = new ModalBuilder().setCustomId(d.customId).setTitle(d.title);
  modal.addComponents(
    new ActionRowBuilder().addComponents(
      new TextInputBuilder()
        .setCustomId(input.customId)
        .setLabel(input.label)
        .setPlaceholder(input.placeholder)
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setValue(input.value),
    ),
  );
  return modal;
}
