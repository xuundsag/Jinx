// Anime metadata: the title we print on the panel, and the logo.
//
// Sources, in the order the spec asks for:
//   1. fanart.tv  - transparent PNG logo, needs a free API key
//   2. TMDB       - transparent PNG logo, needs a free API key
//   3. Kitsu      - cover art, no key needed
//   4. MAL (Jikan)- cover art, no key needed
//
// Every call is optional and every failure is tolerated: the worst case is a
// panel with no thumbnail, which still works.

import { fetchJson } from './http.js';
import { googleSearchUrl } from './urls.js';

const UA = { 'User-Agent': 'anime-stream/1.0 (discord controller)' };

/**
 * Look up a title and logo for a MAL id.
 *
 * @param {object} o
 * @param {number} o.malId
 * @param {string} [o.tmdbKey]
 * @param {string} [o.fanartKey]
 * @param {(m:string)=>void} [o.log]
 * @param {AbortSignal} [o.signal]
 * @returns {Promise<{title:string, logoUrl:string|null, posterUrl:string|null,
 *                    episodeCount:number|null, source:string}>}
 */
export async function lookup({ malId, tmdbKey, fanartKey, log = () => {}, signal } = {}) {
  const out = { title: `MAL ${malId}`, logoUrl: null, posterUrl: null, episodeCount: null, source: 'none' };

  // Kitsu first: it is keyless, fast, and gives us both a title and a cover.
  try {
    const res = await fetchJson(
      `https://kitsu.io/api/edge/anime?filter[text]=&page[limit]=1&filter[malId]=${malId}`,
      { headers: { ...UA, Accept: 'application/vnd.api+json' }, signal, attempts: 2, timeoutMs: 10000 },
    ).catch(async () => {
      // Kitsu rejects filter[malId] on some deployments; fall back to the
      // mapping endpoint which is the documented way.
      return fetchJson(`https://kitsu.io/api/edge/mappings?filter[externalSite]=myanimelist/anime&filter[externalId]=${malId}&page[limit]=1&include=anime`, {
        headers: { ...UA, Accept: 'application/vnd.api+json' },
        signal,
        attempts: 2,
        timeoutMs: 10000,
      });
    });
    const pick = pickKitsu(res);
    if (pick.title) out.title = pick.title;
    if (pick.poster) out.posterUrl = pick.poster;
    if (Number.isFinite(pick.episodeCount)) out.episodeCount = pick.episodeCount;
    if (pick.title) out.source = 'kitsu';
  } catch (e) {
    log(`kitsu lookup failed: ${e.message}`);
  }

  // Jikan for a MAL-canonical title and cover, used when Kitsu had nothing.
  if (out.source === 'none') {
    try {
      const res = await fetchJson(`https://api.jikan.moe/v4/anime/${malId}/full`, { headers: UA, signal, attempts: 2, timeoutMs: 10000 });
      const d = res?.data;
      if (d?.title) {
        out.title = d.title;
        out.posterUrl = d.images?.jpg?.large_image_url || d.images?.jpg?.image_url || null;
        // A still-airing series reports null here, which is why the panel only
        // shows "Episode X of Y" when a number actually exists.
        out.episodeCount = Number.isFinite(d.episodes) ? d.episodes : null;
        out.source = 'mal';
      }
    } catch (e) {
      log(`jikan lookup failed: ${e.message}`);
    }
  }

  // Transparent logos, only when a key is configured.
  if (fanartKey) {
    const logo = await fanartLogo(malId, fanartKey, log, signal);
    if (logo) {
      out.logoUrl = logo;
      out.source = 'fanart.tv';
    }
  }
  if (!out.logoUrl && tmdbKey) {
    const logo = await tmdbLogo(out.title, tmdbKey, log, signal);
    if (logo) {
      out.logoUrl = logo;
      out.source = 'tmdb';
    }
  }
  // No transparent logo anywhere: the cover is better than nothing, and Discord
  // renders it fine as a thumbnail.
  if (!out.logoUrl && out.posterUrl) out.logoUrl = out.posterUrl;

  return out;
}

/** Pull a title and poster out of either Kitsu response shape. */
export function pickKitsu(res) {
  if (!res) return {};
  // Shape 1: an anime search result.
  const anime = res.data?.[0];
  if (anime?.attributes?.titles) {
    const t = anime.attributes.titles;
    return {
      title: t.en_jp || t.en || t.ja_jp || anime.attributes.canonicalTitle || null,
      poster: anime.attributes.posterImage?.original || anime.attributes.posterImage?.large || null,
      episodeCount: Number.isFinite(anime.attributes.episodeCount) ? anime.attributes.episodeCount : null,
    };
  }
  // Shape 2: a mapping with an included anime record.
  const included = res.included?.find((r) => r.type === 'anime');
  if (included?.attributes?.titles) {
    const t = included.attributes.titles;
    return {
      title: t.en_jp || t.en || t.ja_jp || included.attributes.canonicalTitle || null,
      poster: included.attributes.posterImage?.original || null,
      episodeCount: Number.isFinite(included.attributes.episodeCount) ? included.attributes.episodeCount : null,
    };
  }
  return {};
}

/** fanart.tv transparent logo. Needs the TMDB id for that show. */
async function fanartLogo(malId, key, log, signal) {
  try {
    // fanart.tv is keyed on TMDB ids, so translate first.
    const find = await fetchJson(`https://api.jikan.moe/v4/anime/${malId}/full`, { headers: UA, signal, attempts: 1, timeoutMs: 10000 });
    const tmdb = find?.data?.external?.tmdb;
    if (!tmdb) return null;
    const res = await fetchJson(`https://webservice.fanart.tv/v3/tv/${tmdb}?api_key=${key}`, { signal, attempts: 2, timeoutMs: 10000 });
    const logos = res?.hdtvlogo || res?.hdclearlogo || res?.clearlogo;
    if (!Array.isArray(logos) || !logos.length) return null;
    // Prefer an English logo with a transparent background.
    const pick = logos.find((l) => l.lang === 'en' && /\.png$/i.test(l.url)) || logos[0];
    return pick?.url || null;
  } catch (e) {
    log(`fanart.tv lookup failed: ${e.message}`);
    return null;
  }
}

/** TMDB transparent logo, found by searching for the title. */
async function tmdbLogo(title, key, log, signal) {
  try {
    const search = await fetchJson(
      `https://api.themoviedb.org/3/search/tv?api_key=${key}&query=${encodeURIComponent(title)}&page=1`,
      { signal, attempts: 2, timeoutMs: 10000 },
    );
    const id = search?.results?.[0]?.id;
    if (!id) return null;
    const images = await fetchJson(`https://api.themoviedb.org/3/tv/${id}/images?api_key=${key}&include_image_language=en,null`, {
      signal,
      attempts: 2,
      timeoutMs: 10000,
    });
    const logo = images?.logos?.[0];
    if (!logo) return null;
    // w500 keeps the download small; the thumbnail accessory is small anyway.
    return `https://image.tmdb.org/t/p/w500${logo.file_path}`;
  } catch (e) {
    log(`tmdb lookup failed: ${e.message}`);
    return null;
  }
}

export { googleSearchUrl };
