// Container layout snapshot tests.
//
// The panel is the part of this project people actually look at, and Discord
// rejects malformed Components V2 payloads with an unhelpful error. So the
// exact shape is pinned here: if a change alters the layout, these snapshots
// fail and whoever made the change has to look at it deliberately.
//
// Two layers are tested:
//   1. describePanel()  - our own plain description, no discord.js involved
//   2. buildPanel()     - the real discord.js payload, which is what Discord
//                         receives

import test from 'node:test';
import assert from 'node:assert/strict';
import { describePanel, describeSeekModal, buildPanel, buildSeekModal, statusLine, languageLabel, BTN } from '../../shared/src/panel.js';
import { wire } from '../helpers/wire.js';

const BASE = {
  title: 'One Piece',
  episode: 1,
  searchUrl: 'https://www.google.com/search?q=One%20Piece%20episode%201',
  logoUrl: 'https://example.com/logo.png',
  position: 42,
  duration: 1440,
  audio: 'dub',
  captions: true,
  state: 'playing',
  error: null,
};

test('layout snapshot: the full panel description', () => {
  assert.deepEqual(describePanel(BASE), {
    kind: 'container',
    accentColor: null,
    header: null,
    footer: null,
    children: [
      {
        kind: 'section',
        accessory: { kind: 'thumbnail', url: 'https://example.com/logo.png' },
        components: [
          {
            kind: 'text',
            content: '**[One Piece - Episode 1](https://www.google.com/search?q=One%20Piece%20episode%201)**',
          },
        ],
      },
      { kind: 'text', content: 'Duration: 00:42 / 24:00\nLanguage: English (Dub)\nCaptions: On\nStatus: \u{1F7E2} Now playing' },
      { kind: 'separator', spacing: 'small', divider: true },
      {
        kind: 'row',
        components: [
          { kind: 'button', id: 'panel:seek', label: 'Seek', style: 'secondary' },
          { kind: 'button', id: 'panel:back10', label: '\u00AB10', style: 'secondary' },
          { kind: 'button', id: 'panel:toggle', label: 'Pause', style: 'primary' },
          { kind: 'button', id: 'panel:fwd10', label: '\u00BB10', style: 'secondary' },
          { kind: 'button', id: 'panel:skip', label: 'Skip', style: 'secondary' },
        ],
      },
      {
        kind: 'row',
        components: [
          { kind: 'button', id: 'panel:autoplay', label: 'Autoplay: Off', style: 'secondary' },
          { kind: 'button', id: 'panel:stop', label: 'Stop', style: 'danger' },
        ],
      },
    ],
  });
});

test('layout snapshot: the real discord.js container payload', async () => {
  const container = await buildPanel(BASE);
  assert.deepEqual(wire(container.toJSON()), {
    type: 17, // Container
    components: [
      {
        type: 9, // Section
        components: [
          { type: 10, content: '**[One Piece - Episode 1](https://www.google.com/search?q=One%20Piece%20episode%201)**' },
        ],
        accessory: { type: 11, media: { url: 'https://example.com/logo.png' } },
      },
      { type: 10, content: 'Duration: 00:42 / 24:00\nLanguage: English (Dub)\nCaptions: On\nStatus: \u{1F7E2} Now playing' },
      { type: 14, spacing: 1, divider: true },
      {
        type: 1, // ActionRow
        components: [
          { type: 2, custom_id: 'panel:seek', label: 'Seek', style: 2 },
          { type: 2, custom_id: 'panel:back10', label: '\u00AB10', style: 2 },
          { type: 2, custom_id: 'panel:toggle', label: 'Pause', style: 1 },
          { type: 2, custom_id: 'panel:fwd10', label: '\u00BB10', style: 2 },
          { type: 2, custom_id: 'panel:skip', label: 'Skip', style: 2 },
        ],
      },
      {
        type: 1,
        components: [
          { type: 2, custom_id: 'panel:autoplay', label: 'Autoplay: Off', style: 2 },
          { type: 2, custom_id: 'panel:stop', label: 'Stop', style: 4 },
        ],
      },
    ],
  });
});

test('the autoplay button shows the state it is currently in', () => {
  const off = describePanel(BASE).children[4].components[0];
  assert.equal(off.label, 'Autoplay: Off');
  assert.equal(off.style, 'secondary');

  const on = describePanel({ ...BASE, autoplay: true }).children[4].components[0];
  assert.equal(on.label, 'Autoplay: On');
  assert.equal(on.style, 'primary');
});

test('the resume line only appears when there is something to resume', () => {
  const shown = describePanel({ ...BASE, position: 0, resumeFrom: 600 }).children[1].content;
  assert.match(shown, /Resumed from 10:00/);

  // Once playback has moved past the resume point the note is stale, so it goes.
  const hidden = describePanel({ ...BASE, position: 120, resumeFrom: 600 }).children[1].content;
  assert.doesNotMatch(hidden, /Resumed from/);

  const none = describePanel({ ...BASE, position: 0, resumeFrom: 0 }).children[1].content;
  assert.doesNotMatch(none, /Resumed from/);
});

test('the episode counter appears only when the series length is known', () => {
  assert.doesNotMatch(describePanel(BASE).children[1].content, /Episode 1 of/);
  assert.match(describePanel({ ...BASE, episodeCount: 1122 }).children[1].content, /Episode 1 of 1122/);
});

test('the container has no accent colour, header or footer', async () => {
  const json = wire((await buildPanel(BASE)).toJSON());
  assert.equal(json.accent_color, undefined, 'accent colour must not be set');
  assert.equal(json.header, undefined, 'no header');
  assert.equal(json.footer, undefined, 'no footer');
  assert.equal(json.type, 17);
});

test('there is exactly one container and it holds the five spec parts', async () => {
  const json = wire((await buildPanel(BASE)).toJSON());
  const types = json.components.map((c) => c.type);
  // Section, TextDisplay, Separator, ActionRow, ActionRow
  assert.deepEqual(types, [9, 10, 14, 1, 1]);
});

test('every button row respects the Discord five button limit', async () => {
  const json = wire((await buildPanel(BASE)).toJSON());
  for (const row of json.components.filter((c) => c.type === 1)) {
    assert.ok(row.components.length <= 5, 'an action row may hold at most 5 buttons');
    assert.ok(row.components.length >= 1);
  }
});

test('the paused state flips the toggle label and keeps every other button', () => {
  const d = describePanel({ ...BASE, state: 'paused' });
  const row = d.children[3];
  assert.equal(row.components[2].label, 'Resume');
  assert.equal(row.components[0].label, 'Seek');
  assert.equal(row.components[4].label, 'Skip');
  assert.equal(d.children[1].content.includes('\u23F8 Paused'), true);
});

test('status lines match the spec', () => {
  assert.equal(statusLine('playing'), '\u{1F7E2} Now playing');
  assert.equal(statusLine('paused'), '\u23F8 Paused');
  assert.equal(statusLine('loading'), '\u{1F7E1} Loading');
  assert.equal(statusLine('error', 'no dub'), '\u{1F534} Error: no dub');
  assert.equal(statusLine('idle'), '\u26AA Idle');
  // A missing reason still renders something readable.
  assert.equal(statusLine('error'), '\u{1F534} Error: unknown reason');
});

test('language labels distinguish sub from dub', () => {
  assert.equal(languageLabel('dub'), 'English (Dub)');
  assert.equal(languageLabel('sub'), 'Japanese (Sub)');
});

test('an episode with no logo degrades to a plain title line', async () => {
  // Discord rejects a Section with no accessory, so without a logo the title is
  // emitted as a TextDisplay instead. The rest of the panel is unchanged.
  const json = wire((await buildPanel({ ...BASE, logoUrl: null })).toJSON());
  assert.equal(json.components[0].type, 10, 'title becomes a TextDisplay');
  assert.equal(json.components[0].content, '**[One Piece - Episode 1](https://www.google.com/search?q=One%20Piece%20episode%201)**');
  // Separator and both button rows are still present.
  assert.deepEqual(json.components.map((c) => c.type).slice(-3), [14, 1, 1]);
});

test('a logo that is an empty string is treated as no logo', async () => {
  const json = wire((await buildPanel({ ...BASE, logoUrl: '' })).toJSON());
  assert.equal(json.components[0].type, 10);
});

test('duration and captions reflect the state', () => {
  const d = describePanel({ ...BASE, position: 1307, duration: 1307, captions: false, audio: 'sub' });
  const text = d.children[1].content;
  assert.ok(text.startsWith('Duration: 21:47 / 21:47'));
  assert.ok(text.includes('Language: Japanese (Sub)'));
  assert.ok(text.includes('Captions: Off'));
});

test('button ids are stable, because the controller routes on them', () => {
  const d = describePanel(BASE);
  const ids = d.children[3].components.map((b) => b.id).concat(d.children[4].components.map((b) => b.id));
  assert.deepEqual(ids, [BTN.SEEK, BTN.BACK10, BTN.TOGGLE, BTN.FWD10, BTN.SKIP, BTN.AUTOPLAY, BTN.STOP]);
  assert.deepEqual(ids, ['panel:seek', 'panel:back10', 'panel:toggle', 'panel:fwd10', 'panel:skip', 'panel:autoplay', 'panel:stop']);
});

test('seek modal snapshot', () => {
  assert.deepEqual(describeSeekModal(42), {
    kind: 'modal',
    customId: 'panel:seek:modal',
    title: 'Seek to',
    components: [
      {
        kind: 'row',
        components: [
          {
            kind: 'text-input',
            customId: 'seek_value',
            style: 'short',
            label: 'Position',
            placeholder: 'e.g. 90, 1:30 or 01:02:03',
            required: true,
            value: '00:42',
          },
        ],
      },
    ],
  });
});

test('seek modal builds into a real Discord modal payload', async () => {
  const modal = await buildSeekModal(3723);
  const json = wire(modal.toJSON());
  assert.equal(json.custom_id, 'panel:seek:modal');
  assert.equal(json.components[0].components[0].custom_id, 'seek_value');
  assert.equal(json.components[0].components[0].value, '1:02:03');
  assert.equal(json.components[0].components[0].required, true);
});
