// JINX: the controller half.
//
// This is a normal bot. It logs in with a bot token, owns the slash commands and
// the control panel, and tells the streamer what to do over localhost. It never
// touches video, never runs a browser, and never uses a user token.
//
// Why the split exists: Discord does not let bot accounts send video, so the Go
// Live half has to be a separate selfbot process. That half has no commands and
// no interface, which means everything a person interacts with lives here.

import 'dotenv/config';
import * as discord from 'discord.js';
import { IpcClient } from '../../streamer/src/ipc-client.js';
import { loadConfig, assertConfig } from './config.js';
import { registerCommands } from './slash-commands.js';
import { PanelRefresher } from './panel-refresher.js';
import { canUseCommands, canControl, refusalMessage } from './permissions.js';
import { ProgressStore } from '../../shared/src/progress.js';
import { parseTimeInput, formatDuration, clampSeek } from '../../shared/src/time.js';
import { googleSearchUrl } from '../../shared/src/urls.js';
import { lookup as lookupMetadata } from '../../shared/src/metadata.js';
import { BTN, SEEK_MODAL_ID, describePanel, buildContainer } from '../../shared/src/panel.js';

const { Client, GatewayIntentBits, MessageFlags, InteractionType, ModalBuilder, ActionRowBuilder, TextInputBuilder, TextInputStyle } = discord;

const config = loadConfig();
const log = (...args) => console.log(`[${config.botName}]`, ...args);

const ipc = new IpcClient({ baseUrl: config.ipcBaseUrl, token: config.ipcToken });
const progress = new ProgressStore(config.progressFile, log);
const panels = new PanelRefresher({ intervalMs: config.panelRefreshMs, log });

/**
 * One entry per guild that has a stream.
 * @type {Map<string, object>}
 */
const sessions = new Map();

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildVoiceStates],
});

async function main() {
  assertConfig(config);

  // Confirm the streamer answers before registering commands. A bot that
  // replies "streamer offline" to every /play is worse than one that fails at
  // boot and says why.
  await waitForStreamer();

  await client.login(config.botToken);
  log(`logged in as ${client.user.tag}`);

  await registerCommands({ token: config.botToken, clientId: config.clientId, guildId: config.guildId, log });

  setInterval(() => poll().catch((e) => log(`poll failed: ${e.message}`)), 1000).unref?.();
  setInterval(saveAllProgress, config.progressSaveIntervalMs).unref?.();

  const shutdown = async (reason) => {
    log(`${reason}, shutting down`);
    for (const session of sessions.values()) saveProgress(session);
    panels.stop();
    try {
      await ipc.stop();
    } catch {
      /* the streamer may already be gone */
    }
    client.destroy();
    process.exit(0);
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

/** Wait for the streamer, so `node run.js` can start both at the same time. */
async function waitForStreamer(timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs;
  let attempts = 0;
  while (Date.now() < deadline) {
    try {
      await ipc.health();
      log(`streamer reachable at ${config.ipcBaseUrl}`);
      return;
    } catch {
      attempts++;
      if (attempts === 1) log(`waiting for the streamer at ${config.ipcBaseUrl}`);
      await new Promise((r) => setTimeout(r, 1000));
    }
  }
  throw new Error(`The streamer did not answer at ${config.ipcBaseUrl}. Start it with: node run.js streamer`);
}

/**
 * Read the streamer once per tick.
 *
 * Doing this on a timer rather than on a push channel keeps the two processes
 * simple: the streamer only answers questions, and the controller decides when
 * the panel is worth redrawing.
 */
async function poll() {
  for (const [guildId, session] of sessions) {
    let status;
    try {
      const res = await ipc.status();
      status = res.status;
    } catch (err) {
      status = { state: 'error', error: `streamer unreachable: ${err.message}`, position: session.lastStatus?.position || 0, duration: session.lastStatus?.duration || 0 };
    }

    const previous = session.lastStatus?.state;
    session.lastStatus = status;
    saveProgress(session);
    panels.update(guildId, panelState(session, status));

    // Episode finished. The streamer goes idle, so the transition into idle is
    // what tells us the episode is over.
    if (previous && previous !== 'idle' && status.state === 'idle') {
      await onEpisodeEnded(session, status);
    }
  }
}

async function onEpisodeEnded(session, status) {
  saveProgress(session);
  log(`episode ${session.episode} finished`);

  if (!session.autoplay) {
    panels.update(session.guildId, panelState(session, status));
    return;
  }

  const nextEpisode = session.episode + 1;
  if (session.episodeCount && nextEpisode > session.episodeCount) {
    log(`autoplay stopped: ${session.title} has no episode ${nextEpisode}`);
    session.autoplay = false;
    panels.update(session.guildId, panelState(session, status));
    return;
  }

  log(`autoplay: starting episode ${nextEpisode}`);
  try {
    const res = await ipc.play({
      malId: session.malId,
      episode: nextEpisode,
      audio: session.audio,
      captions: session.captions,
      guildId: session.guildId,
      channelId: session.channelId,
      requesterId: session.requesterId,
      title: session.title,
      startAt: 0,
    });
    session.episode = nextEpisode;
    session.resumeFrom = 0;
    session.lastStatus = res.status;
    await panels.force(session.guildId, panelState(session, res.status));
  } catch (err) {
    // A missing episode should not silently kill autoplay forever, but it also
    // should not loop. Turn it off and say so on the panel.
    log(`autoplay could not start episode ${nextEpisode}: ${err.message}`);
    session.autoplay = false;
    session.lastStatus = { ...status, error: `autoplay stopped: ${err.message}` };
    await panels.force(session.guildId, panelState(session, session.lastStatus));
  }
}

/** Assemble everything the panel needs from a session plus the latest status. */
function panelState(session, status) {
  const st = status || {};
  return {
    title: session.title,
    episode: session.episode,
    searchUrl: googleSearchUrl(session.title, session.episode),
    logoUrl: session.logoUrl,
    position: st.position || 0,
    duration: st.duration || 0,
    audio: st.request?.audio || session.audio,
    captions: st.request?.captions ?? session.captions,
    state: st.state || 'loading',
    error: st.error || null,
    autoplay: session.autoplay,
    resumeFrom: session.resumeFrom,
    episodeCount: session.episodeCount,
  };
}

/** The edit payload for a message that carries the panel. */
function panelPayload(session, status) {
  const container = buildContainer(describePanel(panelState(session, status)), discord);
  return { content: null, components: [container] };
}

function saveProgress(session) {
  const st = session.lastStatus;
  if (!st || !st.position) return;
  progress.set({
    userId: session.requesterId,
    malId: session.malId,
    episode: session.episode,
    position: st.position,
    duration: st.duration,
    audio: session.audio,
    captions: session.captions,
  });
}

function saveAllProgress() {
  for (const session of sessions.values()) saveProgress(session);
}

client.on('interactionCreate', async (interaction) => {
  try {
    if (interaction.isChatInputCommand()) return await handleCommand(interaction);
    if (interaction.type === InteractionType.MessageComponent) return await handleButton(interaction);
    if (interaction.type === InteractionType.ModalSubmit) return await handleModal(interaction);
  } catch (err) {
    log(`interaction failed: ${err.message}`);
    const body = { content: `That did not work: ${err.message}`, flags: MessageFlags.Ephemeral };
    try {
      if (interaction.deferred || interaction.replied) await interaction.editReply(body);
      else await interaction.reply(body);
    } catch {
      /* the interaction window already closed */
    }
  }
});

async function handleCommand(interaction) {
  if (!canUseCommands(interaction.member, config)) {
    return interaction.reply({
      content: 'You do not have a role that is allowed to start streams here.',
      flags: MessageFlags.Ephemeral,
    });
  }
  switch (interaction.commandName) {
    case 'play':
      return playCommand(interaction);
    case 'resume':
      return resumeCommand(interaction);
    case 'np':
      return nowPlaying(interaction);
    case 'stop':
      return stopCommand(interaction);
    case 'history':
      return historyCommand(interaction);
    default:
      return interaction.reply({ content: 'Unknown command.', flags: MessageFlags.Ephemeral });
  }
}

/**
 * Validate the options, then hand off to startPlayback.
 * Validation happens before deferring so a bad id fails instantly instead of
 * after a visible "thinking" pause.
 */
async function playCommand(interaction) {
  const malId = interaction.options.getInteger('animeid', true);
  const episode = interaction.options.getNumber('episode', true);
  const audio = interaction.options.getString('audio', true);
  const captions = interaction.options.getString('captions', true) === 'yes';

  const problems = [];
  if (!Number.isInteger(malId) || malId <= 0) problems.push('animeid must be a whole number greater than 0, for example 21.');
  if (!(episode > 0)) problems.push('episode must be a number greater than 0.');
  else if (episode > 100000) problems.push('that episode number is too large to be real.');
  if (problems.length) {
    return interaction.reply({ content: problems.join('\n'), flags: MessageFlags.Ephemeral });
  }

  await interaction.deferReply();
  const resumeFrom = progress.resumeAt(interaction.user.id, malId, episode);
  return startPlayback(interaction, { malId, episode, audio, captions, resumeFrom });
}

async function resumeCommand(interaction) {
  const row = progress.latestUnfinished(interaction.user.id);
  if (!row) {
    return interaction.reply({
      content: 'Nothing part watched on your account yet. Play an episode and Jinx remembers where you stop.',
      flags: MessageFlags.Ephemeral,
    });
  }
  await interaction.deferReply();
  return startPlayback(interaction, {
    malId: row.malId,
    episode: row.episode,
    audio: row.audio,
    captions: row.captions,
    resumeFrom: row.position,
  });
}

/**
 * Look up the series, ask the streamer to start, and post the panel.
 * Shared by /play and /resume.
 */
async function startPlayback(interaction, { malId, episode, audio, captions, resumeFrom = 0 }) {
  const voiceChannel = interaction.member?.voice?.channel;
  if (!voiceChannel) {
    return interaction.editReply({
      content: 'Join a voice channel first, then run the command again. Jinx streams into the channel you are sitting in.',
    });
  }
  if (sessions.has(interaction.guildId)) {
    const existing = sessions.get(interaction.guildId);
    return interaction.editReply({
      content: `A stream is already running here (episode ${existing.episode}). Press Stop or use /stop first.`,
    });
  }

  await interaction.editReply({ content: `Looking up MAL ${malId}, episode ${episode}...` });

  // Title and logo. A failure here is not fatal: a panel without a thumbnail
  // still works, so we carry on with a plain title.
  const meta = await lookupMetadata({ malId, tmdbKey: config.tmdbKey, fanartKey: config.fanartKey, log }).catch((err) => {
    log(`metadata lookup failed: ${err.message}`);
    return { title: `MAL ${malId}`, logoUrl: null, episodeCount: null };
  });

  const session = {
    guildId: interaction.guildId,
    channelId: voiceChannel.id,
    requesterId: interaction.user.id,
    malId,
    episode,
    audio,
    captions,
    autoplay: config.autoplayDefault,
    title: meta.title,
    logoUrl: meta.logoUrl,
    episodeCount: meta.episodeCount ?? null,
    resumeFrom,
    message: null,
    lastStatus: null,
  };

  let res;
  try {
    res = await ipc.play({
      malId,
      episode,
      audio,
      captions,
      guildId: interaction.guildId,
      channelId: voiceChannel.id,
      requesterId: interaction.user.id,
      title: meta.title,
      startAt: resumeFrom,
    });
  } catch (err) {
    sessions.delete(interaction.guildId);
    return interaction.editReply({ content: describeIpcFailure(err, { malId, episode }) });
  }

  session.lastStatus = res.status;
  sessions.set(interaction.guildId, session);

  const message = await interaction.editReply(panelPayload(session, res.status));
  session.message = message;
  panels.setTarget(interaction.guildId, message);

  if (resumeFrom > 0) log(`continuing episode ${episode} from ${formatDuration(resumeFrom)}`);
  return message;
}

async function nowPlaying(interaction) {
  const session = sessions.get(interaction.guildId);
  if (!session) {
    return interaction.reply({ content: 'Nothing is streaming in this server right now.', flags: MessageFlags.Ephemeral });
  }
  const st = session.lastStatus || {};
  const lines = [
    `**${session.title}** episode ${session.episode}`,
    `${formatDuration(st.position || 0)} of ${formatDuration(st.duration || 0)}`,
    `${session.audio === 'dub' ? 'English dub' : 'Japanese audio with subtitles'}, captions ${session.captions ? 'on' : 'off'}`,
    `Autoplay is ${session.autoplay ? 'on' : 'off'}`,
    `Started by <@${session.requesterId}>`,
  ];
  return interaction.reply({ content: lines.join('\n'), flags: MessageFlags.Ephemeral });
}

async function stopCommand(interaction) {
  const session = sessions.get(interaction.guildId);
  if (!session) {
    return interaction.reply({ content: 'Nothing is streaming here.', flags: MessageFlags.Ephemeral });
  }
  if (!canControl({ member: interaction.member, requesterId: session.requesterId, allowedRoleIds: config.allowedRoleIds })) {
    return interaction.reply({
      content: refusalMessage({ requesterId: session.requesterId, allowedRoleIds: config.allowedRoleIds }),
      flags: MessageFlags.Ephemeral,
    });
  }
  await teardown(interaction.guildId);
  return interaction.reply({ content: 'Stopped and left the voice channel.', flags: MessageFlags.Ephemeral });
}

async function historyCommand(interaction) {
  const limit = Math.min(25, Math.max(1, interaction.options.getInteger('limit') || 5));
  const rows = progress.forUser(interaction.user.id).slice(0, limit);
  if (!rows.length) {
    return interaction.reply({
      content: 'Nothing recorded yet. Whatever you play is saved so you can pick it up later with /resume.',
      flags: MessageFlags.Ephemeral,
    });
  }
  const lines = rows.map((row) => {
    const state = row.finished ? 'finished' : `stopped at ${formatDuration(row.position)} of ${formatDuration(row.duration)}`;
    return `MAL ${row.malId} episode ${row.episode} (${row.audio}, captions ${row.captions ? 'on' : 'off'}) ${state}`;
  });
  return interaction.reply({ content: lines.join('\n'), flags: MessageFlags.Ephemeral });
}

async function handleButton(interaction) {
  const session = sessions.get(interaction.guildId);
  if (!session) {
    return interaction.reply({ content: 'That panel belongs to a stream that has already ended.', flags: MessageFlags.Ephemeral });
  }
  if (!canControl({ member: interaction.member, requesterId: session.requesterId, allowedRoleIds: config.allowedRoleIds })) {
    return interaction.reply({
      content: refusalMessage({ requesterId: session.requesterId, allowedRoleIds: config.allowedRoleIds }),
      flags: MessageFlags.Ephemeral,
    });
  }

  const id = interaction.customId;
  const status = session.lastStatus || {};

  // Autoplay is controller-side state, so it needs no round trip.
  if (id === BTN.AUTOPLAY) {
    session.autoplay = !session.autoplay;
    log(`autoplay ${session.autoplay ? 'on' : 'off'} for ${session.title}`);
    await interaction.deferUpdate();
    return interaction.editReply(panelPayload(session, status));
  }

  await interaction.deferUpdate();

  switch (id) {
    case BTN.SEEK:
      return interaction.showModal(buildSeekModal(status.position || 0));
    case BTN.BACK10:
      return applySeek(session, Math.max(0, (status.position || 0) - 10), interaction);
    case BTN.FWD10:
      return applySeek(session, (status.position || 0) + 10, interaction);
    case BTN.TOGGLE:
      return togglePlayPause(session, status, interaction);
    case BTN.SKIP:
      return skip(session, interaction);
    case BTN.STOP:
      await teardown(interaction.guildId);
      return interaction.editReply(panelPayload(session, { state: 'idle' }));
    default:
      return interaction.editReply(panelPayload(session, status));
  }
}

async function applySeek(session, seconds, interaction) {
  const duration = session.lastStatus?.duration || 0;
  const check = clampSeek(seconds, duration);
  if (!check.ok) {
    return interaction.editReply(panelPayload(session, { ...session.lastStatus, error: check.error }));
  }
  try {
    const res = await ipc.seek(check.seconds);
    session.lastStatus = res.status;
  } catch (err) {
    log(`seek failed: ${err.message}`);
    return interaction.editReply(panelPayload(session, { ...session.lastStatus, error: err.message }));
  }
  panels.update(session.guildId, panelState(session, session.lastStatus));
  return interaction.editReply(panelPayload(session, session.lastStatus));
}

async function togglePlayPause(session, status, interaction) {
  try {
    const res = status.state === 'paused' ? await ipc.resume() : await ipc.pause();
    session.lastStatus = res.status;
  } catch (err) {
    log(`pause or resume failed: ${err.message}`);
    return interaction.editReply(panelPayload(session, { ...status, error: err.message }));
  }
  panels.update(session.guildId, panelState(session, session.lastStatus));
  return interaction.editReply(panelPayload(session, session.lastStatus));
}

async function skip(session, interaction) {
  try {
    const res = await ipc.skip();
    session.lastStatus = res.status;
    log(`skip: ${res.reason}`);
  } catch (err) {
    log(`skip failed: ${err.message}`);
    return interaction.editReply(panelPayload(session, { ...session.lastStatus, error: err.message }));
  }
  panels.update(session.guildId, panelState(session, session.lastStatus));
  return interaction.editReply(panelPayload(session, session.lastStatus));
}

async function handleModal(interaction) {
  if (interaction.customId !== SEEK_MODAL_ID) {
    return interaction.reply({ content: 'Unknown form.', flags: MessageFlags.Ephemeral });
  }
  const session = sessions.get(interaction.guildId);
  if (!session) {
    return interaction.reply({ content: 'That panel belongs to a stream that has already ended.', flags: MessageFlags.Ephemeral });
  }
  if (!canControl({ member: interaction.member, requesterId: session.requesterId, allowedRoleIds: config.allowedRoleIds })) {
    return interaction.reply({
      content: refusalMessage({ requesterId: session.requesterId, allowedRoleIds: config.allowedRoleIds }),
      flags: MessageFlags.Ephemeral,
    });
  }

  const raw = interaction.fields.getTextInputValue('seek_value');
  const parsed = parseTimeInput(raw);
  if (!parsed.ok) {
    return interaction.reply({ content: parsed.error, flags: MessageFlags.Ephemeral });
  }
  const check = clampSeek(parsed.seconds, session.lastStatus?.duration || 0);
  if (!check.ok) {
    return interaction.reply({ content: check.error, flags: MessageFlags.Ephemeral });
  }

  await interaction.deferUpdate();
  try {
    const res = await ipc.seek(check.seconds);
    session.lastStatus = res.status;
  } catch (err) {
    log(`seek failed: ${err.message}`);
    return interaction.editReply(panelPayload(session, { ...session.lastStatus, error: err.message }));
  }
  panels.update(session.guildId, panelState(session, session.lastStatus));
  return interaction.editReply(panelPayload(session, session.lastStatus));
}

/** Stop the stream, save where it reached, and blank the panel. */
async function teardown(guildId) {
  const session = sessions.get(guildId);
  if (!session) return;
  saveProgress(session);
  try {
    await ipc.stop();
  } catch (err) {
    log(`stop failed: ${err.message}`);
  }
  panels.dropTarget(guildId);
  sessions.delete(guildId);
  if (session.message) {
    await session.message.edit(panelPayload(session, { state: 'idle' })).catch(() => {});
  }
}

function buildSeekModal(position) {
  return new ModalBuilder()
    .setCustomId(SEEK_MODAL_ID)
    .setTitle('Seek to')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('seek_value')
          .setLabel('Position')
          .setPlaceholder('e.g. 90, 1:30 or 01:02:03')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setValue(formatDuration(position)),
      ),
    );
}

/** Turn a streamer failure into a sentence that says what to do next. */
export function describeIpcFailure(err, ctx) {
  const message = err?.message || 'unknown error';
  if (err?.code === 'invalid_id') return `That is not a valid MAL id. ${message}`;
  if (err?.code === 'missing_episode') return `An episode number is required. ${message}`;
  if (err?.code === 'no_voice') return 'You need to be in a voice channel. Join one and try again.';
  if (/no dubbed version/i.test(message)) {
    return `There is no dubbed version of episode ${ctx.episode}. Run it again with audio: sub, or pick a series that has a dub.`;
  }
  if (/not on the video server|code 410|no episode/i.test(message)) {
    return `Episode ${ctx.episode} of MAL ${ctx.malId} is not on the video server. Check the episode number, or try audio: sub.`;
  }
  if (err?.status === 409) return message;
  if (/ECONNREFUSED|unreachable/i.test(message)) {
    return `The streamer process is not answering at ${config.ipcBaseUrl}. Start it with: node run.js streamer`;
  }
  return `Playback failed: ${message}`;
}

main().catch((err) => {
  console.error(`[${config.botName}] fatal:`, err.message);
  process.exit(1);
});
