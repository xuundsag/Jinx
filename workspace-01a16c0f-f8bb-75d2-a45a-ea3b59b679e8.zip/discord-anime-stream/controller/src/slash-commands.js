// Slash command definitions.
//
// Registered per guild when GUILD_ID is set, which makes them appear instantly
// and keeps a mistake off the global list. Without GUILD_ID they go global and
// can take up to an hour to appear.

import { REST, Routes, SlashCommandBuilder } from 'discord.js';

export function buildCommands(botName) {
  const play = new SlashCommandBuilder()
    .setName('play')
    .setDescription(`Stream an anime episode into your voice channel with ${botName}`)
    .addIntegerOption((o) =>
      o.setName('animeid').setDescription('MyAnimeList id of the series, for example 21 for One Piece').setRequired(true),
    )
    .addNumberOption((o) =>
      o.setName('episode').setDescription('Episode number, decimals allowed for specials like 13.5').setRequired(true),
    )
    .addStringOption((o) =>
      o
        .setName('audio')
        .setDescription('Sub keeps the Japanese voice track, dub replaces it with English')
        .setRequired(true)
        .addChoices(
          { name: 'Sub (Japanese)', value: 'sub' },
          { name: 'Dub (English)', value: 'dub' },
        ),
    )
    .addStringOption((o) =>
      o
        .setName('captions')
        .setDescription('Burn English subtitles into the video')
        .setRequired(true)
        .addChoices(
          { name: 'Yes', value: 'yes' },
          { name: 'No', value: 'no' },
        ),
    );

  const resume = new SlashCommandBuilder()
    .setName('resume')
    .setDescription('Continue the last episode you stopped part way through');

  const np = new SlashCommandBuilder().setName('np').setDescription('Show what is playing right now');

  const stop = new SlashCommandBuilder().setName('stop').setDescription('End the current stream and leave voice');

  const history = new SlashCommandBuilder()
    .setName('history')
    .setDescription('List the episodes you have started, newest first')
    .addIntegerOption((o) => o.setName('limit').setDescription('How many to show, default 5'));

  return [play, resume, np, stop, history];
}

/**
 * Push the command list to Discord.
 *
 * @param {object} o
 * @param {string} o.token bot token
 * @param {string} o.clientId application id
 * @param {string} [o.guildId] when set, registers per guild
 * @param {(m: string) => void} [o.log]
 */
export async function registerCommands({ token, clientId, guildId, log = () => {} }) {
  const rest = new REST({ version: '10' }).setToken(token);
  const body = buildCommands(process.env.BOT_NAME || 'Jinx').map((c) => c.toJSON());
  const route = guildId ? Routes.applicationGuildCommands(clientId, guildId) : Routes.applicationCommands(clientId);
  await rest.put(route, { body });
  log(`registered ${body.length} commands ${guildId ? `in guild ${guildId}` : 'globally'}`);
  return body;
}
