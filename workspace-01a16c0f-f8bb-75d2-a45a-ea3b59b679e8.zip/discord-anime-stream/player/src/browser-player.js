// The browser half of the playback pipeline.
//
// Chromium runs on the virtual display, loads our own minimal page, and plays
// the HLS playlist that the local proxy serves. Audio goes into the PulseAudio
// null sink. A separate FFmpeg process (see capture.js) records both.
//
// Everything the controller asks for - pause, resume, seek, status - is done by
// touching the <video> element through page.evaluate. No synthetic clicks, no
// keyboard, nothing that depends on the page layout.

import { EventEmitter } from 'node:events';
import { mediaHeaders } from '@anime-stream/shared/urls.js';
import { sleep } from '@anime-stream/shared/retry.js';

export class BrowserPlayer extends EventEmitter {
  /**
   * @param {object} o
   * @param {import('./static-server.js').StaticServer} o.staticServer
   * @param {import('./display.js').VirtualDisplay} [o.display]
   * @param {import('./display.js').NullSinkAudio} [o.audio]
   * @param {{width:number,height:number}} [o.viewport]
   * @param {(m:string)=>void} [o.log]
   */
  constructor({ staticServer, display, audio, viewport = { width: 1280, height: 720 }, log = () => {} } = {}) {
    super();
    this.staticServer = staticServer;
    this.display = display;
    this.audio = audio;
    this.viewport = viewport;
    this.log = log;
    this.browser = null;
    this.context = null;
    this.page = null;
    this.crashed = false;
    this.playlistUrl = null;
  }

  /** Launch Chromium. Safe to call again after a crash. */
  async launch() {
    if (this.page) return this;
    const { chromium } = await import('playwright');

    const args = [
      '--autoplay-policy=no-user-gesture-required', // never wait for a click
      '--disable-blink-features=AutomationControlled', // some CDNs reject the automation flag
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-dev-shm-usage', // /dev/shm is small in containers
      '--window-size=1280,720',
      '--start-fullscreen',
      '--hide-scrollbars',
      '--mute-audio=false',
      '--force-color-profile=srgb',
      // Software rendering: a VPS has no GPU, and swiftshader is good enough
      // for 720p30 capture.
      '--enable-unsafe-swiftshader',
    ];
    if (this.audio?.started) {
      // Point Chromium's PulseAudio client at the daemon we started.
      const server = pulseServerString(this.audio);
      if (server) args.push(`--pulse-server=${server}`);
    }

    this.browser = await chromium.launch({
      headless: false, // headful, but on a virtual display - we need a real frame buffer
      args,
      env: buildEnv(this.display, this.audio),
    });

    this.browser.on('disconnected', () => {
      if (this.page) {
        this.crashed = true;
        this.log('chromium disconnected unexpectedly');
        this.emit('crash');
      }
    });

    this.context = await this.browser.newContext({
      viewport: this.viewport,
      // No custom user agent: the proxy already adds the headers upstream.
    });
    this.page = await this.context.newPage();
    this.page.on('pageerror', (e) => this.log(`page error: ${e.message}`));
    this.page.on('console', (m) => {
      if (m.type() === 'error') this.log(`console: ${m.text().slice(0, 200)}`);
    });

    // Wait for the DOM, not for the load event. The page inlines all of
    // hls.js, and waiting for `load` has been observed to stall on a virtual
    // display even though the page is fully usable. What actually matters is
    // that window.__player exists, which the next line checks.
    await this.page.goto(this.staticServer.playerUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await this.page.waitForFunction(() => !!window.__player, { timeout: 20000 });
    this.crashed = false;
    this.log('chromium ready');
    return this;
  }

  /**
   * Start playback of a playlist.
   *
   * @param {object} o
   * @param {string} o.playlistUrl proxied master playlist
   * @param {number} [o.startAt] seconds to start from (used when resuming)
   * @param {string} [o.captionUrl] WebVTT to render in page
   * @param {boolean} [o.captions] whether captions should be visible
   */
  async load({ playlistUrl, startAt = 0, captionUrl, captions = false }) {
    if (!this.page) await this.launch();
    this.playlistUrl = playlistUrl;

    let vtt = '';
    if (captionUrl && captions) {
      try {
        const res = await fetch(captionUrl, { headers: mediaHeaders() });
        if (res.ok) vtt = await res.text();
        else this.log(`caption fetch failed: HTTP ${res.status}`);
      } catch (e) {
        this.log(`caption fetch error: ${e.message}`);
      }
    }

    await this.page.evaluate(
      ([u, s, text, on]) => window.__player.loadCaptions(text, on),
      [playlistUrl, startAt, vtt, captions],
    );
    await this.page.evaluate(
      ([u, s]) => window.__player.load({ url: u, startAt: s }),
      [playlistUrl, startAt],
    );

    // Wait until the video really has frames, so we never start capturing black.
    const ok = await this.waitForReady(30000);
    if (!ok) {
      const st = await this.status().catch(() => null);
      throw new Error(`video did not become ready (phase=${st?.phase}, error=${st?.error})`);
    }
    if (startAt > 0) await this.page.evaluate((t) => window.__player.seek(t), startAt);
    return this;
  }

  /** Poll the page until the video is producing frames. */
  async waitForReady(timeoutMs = 30000) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const st = await this.status().catch(() => null);
      if (st && st.readyState >= 2 && st.videoWidth > 0 && st.duration > 0) return true;
      if (st?.phase === 'error' && /no hls support/.test(st.error || '')) return false;
      await sleep(250);
    }
    return false;
  }

  /** Read the live player state out of the page. */
  async status() {
    if (!this.page) return null;
    return this.page.evaluate(() => window.__player.status());
  }

  async pause() {
    if (!this.page) return false;
    return this.page.evaluate(() => window.__player.pause());
  }

  async resume() {
    if (!this.page) return false;
    await this.page.evaluate(() => window.__player.play());
    return true;
  }

  /**
   * Seek to an absolute position. Returns the position the video settled on.
   */
  async seek(seconds) {
    if (!this.page) return null;
    const target = await this.page.evaluate((t) => window.__player.seek(t), seconds);
    // Give the demuxer a moment, then report the real clock.
    await sleep(400);
    const st = await this.status();
    return st?.currentTime ?? target;
  }

  async setCaptions(on) {
    if (!this.page) return false;
    return this.page.evaluate((v) => window.__player.setCaptions(v), !!on);
  }

  /** Kill the browser and every process under it. */
  async stop() {
    const p = this.page;
    this.page = null;
    try {
      if (this.context) await this.context.close();
    } catch { /* already gone */ }
    try {
      if (this.browser) await this.browser.close();
    } catch { /* already gone */ }
    this.context = null;
    this.browser = null;
    void p;
  }
}

/** Build the child environment with the right DISPLAY and Pulse paths. */
function buildEnv(display, audio) {
  const env = { ...process.env };
  if (display?.envDisplay) env.DISPLAY = display.envDisplay;
  if (audio?.runtimeDir) {
    env.PULSE_RUNTIME_PATH = audio.runtimeDir;
    env.XDG_RUNTIME_DIR = audio.runtimeDir;
  }
  return env;
}

/** The --pulse-server value Chromium wants, when we can determine it. */
function pulseServerString(audio) {
  if (!audio?.runtimeDir) return null;
  return `unix:${audio.runtimeDir}/pulse/native`;
}
