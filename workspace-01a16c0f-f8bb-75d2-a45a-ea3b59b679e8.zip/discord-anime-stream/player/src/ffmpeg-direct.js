// Fallback path: no browser at all.
//
// When the Chromium capture path is unavailable (Chromium crashed, missing
// system libraries, not enough RAM) we skip the browser completely and hand the
// playlist straight to FFmpeg:
//
//   - the local HLS proxy serves the playlist, which solves the disguised
//     segment extensions and the Referer requirement
//   - seeking uses -ss placed after -i, which decodes to the exact frame
//     instead of snapping to the previous keyframe
//   - captions are burnt in with the subtitles filter
//   - the picture is letterboxed to exactly 1280x720 so Discord always sees a
//     sane frame size
//
// Output is the same NUT-on-stdout stream the capture path produces, so nothing
// downstream has to know which path is in use.

import { spawn, execFile } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { EventEmitter } from 'node:events';
import { track } from './process-guard.js';
import { mediaHeaders } from '@anime-stream/shared/urls.js';

/** Pick the most useful line out of FFmpeg's stderr for an error message. */
function firstMeaningfulLine(stderr) {
  const lines = String(stderr || '')
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l && !/^frame=|^size=/.test(l) && !/^(Input|Output|Stream|Metadata|Duration|encoder|Side data)\b/.test(l));
  return lines.find((l) => /error|invalid|no such|not found|failed/i.test(l)) || lines[lines.length - 1] || '';
}

/**
 * Ask ffprobe how long a playlist runs for.
 *
 * The direct path has no video element to report a duration, and without one
 * the panel shows 00:00 and the engine never learns the episode finished.
 * Returns null when the answer is not available rather than throwing, because
 * a missing duration should not stop playback.
 */
export function probeDuration(url) {
  return new Promise((resolve) => {
    execFile(
      'ffprobe',
      ['-v', 'error', '-show_entries', 'format=duration', '-of', 'default=nw=1:nk=1', url],
      { timeout: 20000 },
      (err, stdout) => {
        if (err) return resolve(null);
        const value = Number.parseFloat(String(stdout).trim());
        resolve(Number.isFinite(value) && value > 0 ? value : null);
      },
    );
  });
}

export class FfmpegDirect extends EventEmitter {
  /**
   * @param {object} o
   * @param {string} o.playlistUrl proxied master playlist
   * @param {string} [o.captionUrl] WebVTT to burn in
   * @param {boolean} [o.captions]
   * @param {number} [o.startAt] seconds to start from
   * @param {{width:number,height:number}} [o.size]
   * @param {number} [o.fps]
   * @param {(m:string)=>void} [o.log]
   */
  constructor({ playlistUrl, captionUrl, captions = false, startAt = 0, streamLoop = 0, size = { width: 1280, height: 720 }, fps = 30, log = () => {} } = {}) {
    super();
    this.playlistUrl = playlistUrl;
    this.streamLoop = streamLoop;
    this.captionUrl = captionUrl || null;
    this.captions = captions;
    this.startAt = startAt;
    this.size = size;
    this.fps = fps;
    this.log = log;
    this.proc = null;
    this.framesDecoded = 0;
    this.lastFrameAt = Date.now();
    this.tmpDir = null;
    /** Set when stop() is called, so the exit handler knows it was on purpose. */
    this.stopping = false;
  }

  /**
   * Download the subtitle file so the subtitles filter can read it from disk.
   * FFmpeg's filter graph needs a real path, and it also needs the file to stay
   * put for the whole run, so we keep it until stop().
   */
  async prepareSubtitles() {
    if (!this.captions || !this.captionUrl) return null;
    try {
      const res = await fetch(this.captionUrl, { headers: mediaHeaders() });
      if (!res.ok) {
        this.log(`caption fetch failed: HTTP ${res.status}`);
        return null;
      }
      const text = await res.text();
      if (!text.includes('-->')) {
        this.log('caption file has no cues, skipping burn-in');
        return null;
      }
      this.tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'anime-subs-'));
      const file = path.join(this.tmpDir, 'captions.vtt');
      fs.writeFileSync(file, text, 'utf8');
      this.log(`captions saved to ${file}`);
      return file;
    } catch (e) {
      this.log(`caption fetch error: ${e.message}`);
      return null;
    }
  }

  /**
   * Build the FFmpeg argument list.
   * @param {string|null} subtitleFile
   */
  buildArgs(subtitleFile) {
    const { width, height } = this.size;
    const args = ['-hide_banner', '-loglevel', 'warning', '-stats'];

    // Accurate seeking: -ss after -i decodes from the previous keyframe to the
    // exact frame we asked for. Slow to start, correct result.
    if (this.startAt > 0) args.push('-ss', String(this.startAt));

    // -re reads the input at its native rate. Without it FFmpeg encodes as fast
    // as the CPU allows - measured at 17x on the test fixture - and the whole
    // episode piles up in the pipe before Discord has consumed any of it. On a
    // small VPS that is hundreds of megabytes held in memory. Pacing the input
    // keeps the buffer bounded.
    args.push('-re');

    // -1 repeats the input forever. Only used by the soak test, which needs
    // hours of media from a short fixture; real playback sets 0.
    if (this.streamLoop) args.push('-stream_loop', String(this.streamLoop));

    args.push('-i', this.playlistUrl);

    // Video filter chain: burn captions if asked, then letterbox to the target.
    const filters = [];
    if (subtitleFile) {
      // The filter parser treats ':' and '\' specially, so escape the path.
      const escaped = subtitleFile.replace(/\\/g, '/').replace(/:/g, '\\:');
      filters.push(`subtitles='${escaped}'`);
    }
    filters.push(`scale=${width}:${height}:force_original_aspect_ratio=decrease`);
    filters.push(`pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2:color=black`);
    filters.push(`fps=${this.fps}`);
    filters.push('setsar=1');

    args.push(
      '-map', '0:v:0',
      '-map', '0:a:0?', // audio may be absent; do not fail if so
      '-vf', filters.join(','),
      '-c:v', 'libx264',
      '-preset', 'ultrafast',
      '-tune', 'zerolatency',
      '-pix_fmt', 'yuv420p',
      '-profile:v', 'baseline',
      '-level', '3.1',
      '-g', String(this.fps * 2),
      '-r', String(this.fps),
      '-b:v', '2500k',
      '-maxrate', '2500k',
      '-bufsize', '5000k',
      '-c:a', 'libopus',
      '-b:a', '128k',
      '-ar', '48000',
      '-ac', '2',
      '-fflags', '+genpts',
      '-f', 'nut',
      '-',
    );
    return args;
  }

  /** Start and return the readable NUT stream. */
  async start() {
    const subtitleFile = await this.prepareSubtitles();
    const args = this.buildArgs(subtitleFile);
    this.log(`ffmpeg direct ${args.slice(0, 10).join(' ')} ...`);
    this.proc = track(spawn('ffmpeg', args, { stdio: ['ignore', 'pipe', 'pipe'] }));

    let stderrTail = '';
    this.proc.stderr?.on('data', (d) => {
      const s = d.toString();
      stderrTail = (stderrTail + s).slice(-4000);
      const m = /frame=\s*(\d+)/.exec(s);
      if (m) {
        this.framesDecoded = Number(m[1]);
        this.lastFrameAt = Date.now();
      }
    });
    this.proc.on('exit', (code, signal) => {
      this.log(`ffmpeg direct exited code=${code} signal=${signal}`);
      // Surface a readable reason: a silent exit makes a broken stream very hard
      // to diagnose on a headless box.
      if (code !== 0 && code !== null && !this.stopping) {
        const reason = firstMeaningfulLine(stderrTail);
        if (reason) this.log(`ffmpeg direct failed: ${reason}`);
      }
      this.emit('exit', { code, signal, stderrTail });
    });
    this.proc.on('error', (e) => this.emit('error', e));

    this.lastFrameAt = Date.now();
    return this.proc.stdout;
  }

  get secondsSinceFrame() {
    return (Date.now() - this.lastFrameAt) / 1000;
  }

  /**
   * Stop FFmpeg and wait for it to be gone.
   *
   * Waiting matters: an encoder left behind keeps consuming CPU and memory
   * long after the caller moved on, and a box that leaks one per playback will
   * eventually die. Escalate to SIGKILL rather than leak it.
   */
  async stop() {
    this.stopping = true;
    if (this.proc) {
      const p = this.proc;
      this.proc = null;
      const exited = new Promise((resolve) => p.once('exit', resolve));
      try { p.kill('SIGTERM'); } catch { /* already gone */ }
      const survived = await Promise.race([
        exited.then(() => false),
        new Promise((resolve) => setTimeout(() => resolve(true), 2000)),
      ]);
      if (survived) {
        try { p.kill('SIGKILL'); } catch { /* already gone */ }
        await Promise.race([exited, new Promise((resolve) => setTimeout(resolve, 1500))]);
      }
    }
    if (this.tmpDir) {
      try { fs.rmSync(this.tmpDir, { recursive: true, force: true }); } catch { /* ignore */ }
      this.tmpDir = null;
    }
  }
}
