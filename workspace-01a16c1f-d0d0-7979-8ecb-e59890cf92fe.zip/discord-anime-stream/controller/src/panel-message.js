// Turning a playback state into the message payload Discord should receive.
//
// This lives in its own module rather than inline in the controller entry point
// so it can be imported and tested. The entry point logs in as soon as it is
// imported, which makes anything defined there impossible to reach from a test.

import { describePanel, buildContainer } from '@anime-stream/shared/panel.js';
import { MessageFlags } from 'discord.js';

/**
 * The payload for a message that carries the control panel.
 *
 * The IsComponentsV2 flag is not optional. Discord only accepts a Container as
 * a top level component on a message carrying that flag. Leave it out and the
 * API rejects the message with:
 *
 *   Invalid Form Body
 *   components[0][UNION_TYPE_CHOICES]: Value of field "type" must be one of (1,)
 *
 * which is it saying that an ActionRow is the only thing allowed there.
 *
 * @param {object} state playback state, the shape describePanel takes
 * @param {object} builders the discord.js module
 */
export function panelMessage(state, builders) {
  const container = buildContainer(describePanel(state), builders);
  return {
    // Components V2 messages carry no text content and no embeds.
    content: null,
    components: [container],
    flags: MessageFlags.IsComponentsV2,
  };
}

/**
 * The flag a deferral needs.
 *
 * Deferring is the call that creates the message, so the flag has to go there.
 * Editing an existing message into Components V2 afterwards does not work.
 */
export const PANEL_MESSAGE_FLAGS = MessageFlags.IsComponentsV2;
