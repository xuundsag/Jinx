# Jinx

Streams anime into a Discord voice channel as Go Live video, driven by a slash
command and an in-channel control panel.

Two programs, deliberately kept apart:

- **streamer** logs in with a **user** token, joins voice and broadcasts video.
  It has no commands and no interface.
- **controller** is a normal **application bot**. It owns `/play` and the panel,
  and never touches video.

They talk over HTTP on 127.0.0.1.

> ## Read this first
>
> **A selfbot violates Discord's Terms of Service.** Automating a user account
> can get that account permanently banned. This is not a theoretical risk and
> there is no setting that makes it safe.
>
> **Use a throwaway account you do not care about losing.** Do not use your
> main account, and do not use an account attached to anything you would miss.
>
> The controller half is an ordinary application bot and is fine. Only the
> streamer half, which needs a user token because application bots cannot
> stream video, breaks the rules.

## Contents

- [Install](#install)
- [Configure](#configure)
- [Run](#run)
- [Using it](#using-it)
- [Architecture](#architecture)
- [Why it is built this way](#why-it-is-built-this-way)
- [Testing](#testing)
- [What has not been verified](#what-has-not-been-verified)
- [Troubleshooting](#troubleshooting)

## Install

Debian or Ubuntu, as a user with sudo:

```bash
git clone <your repo> jinx && cd jinx
npm run setup
```

That installs ffmpeg, Xvfb, PulseAudio and the Chromium libraries, then the npm
packages and Playwright's Chromium.

**Node 22.4.0 or newer.** `@dank074/discord-video-stream` requires it. Node 20
runs everything except the Discord streaming step.

To check the machine afterwards:

```bash
node scripts/diagnose.js
```

This runs the whole capture pipeline against a locally generated test clip. It
needs no token and no network.

## Configure

```bash
cp .env.example .env
```

Then edit `.env`. The variables that matter:

| Variable | What it is |
| --- | --- |
| `DISCORD_USER_TOKEN` | The throwaway account the streamer logs in as |
| `DISCORD_BOT_TOKEN` | The application bot that owns `/play` |
| `DISCORD_CLIENT_ID` | That bot's application id, for registering the command |
| `GUILD_ID` | Where to register the command. Leave empty for global, which takes up to an hour to appear |
| `ALLOWED_ROLE_IDS` | Roles allowed to press panel buttons. Empty means only the requester |
| `IPC_TOKEN` | Shared secret between the two processes on localhost |
| `PLAYER_BACKEND` | `auto`, `browser` or `ffmpeg` |
| `MEGAPLAY_MIRRORS` | Comma separated fallback hosts |
| `TMDB_API_KEY` / `FANART_API_KEY` | For transparent logos. Optional |

Tokens live only in `.env`, which is gitignored. They are never written to the
log; the log redaction is in `shared/src/http.js` and is covered by a unit test.

Check the tokens are real before starting anything:

```bash
node run.js check
```

This asks Discord about each token and tells you which account each one is. It
prints the account name, never the token.

## Run

```bash
node run.js
```

Starts both, prefixes their output so you can tell them apart, and stops them
together on Ctrl-C. Either half can also run on its own:

```bash
node run.js streamer
node run.js controller
```

They are separate processes on purpose, so a crash in one does not take the
other down, and you can restart the streamer without dropping the panel.

## Using it

```
/play animeid:21 episode:4 audio:dub captions:yes
```

- `animeid` is the MyAnimeList id.
- `episode` is a number.
- `audio` is `sub` or `dub`. If no dub exists you get the sub and the panel
  says so.
- `captions` is `yes` or `no`.

`/resume` picks up the last episode you did not finish. Progress is saved
periodically to `PROGRESS_FILE`, so it survives a restart.

The panel shows duration, language, captions and status, with buttons to seek,
jump ten seconds either way, pause, skip the opening or ending, toggle autoplay
and stop. Pressing **Seek** opens a box that takes `90`, `1:30` or `01:02:03`.

Only the person who started playback, or a role in `ALLOWED_ROLE_IDS`, can press
the buttons. Everyone else gets a message that only they can see.

## Architecture

```
                     Discord
                        |
        +---------------+----------------+
        |                                |
   user token                       bot token
        |                                |
  +-----v------+                   +-----v-------+
  |  STREAMER  |                   | CONTROLLER  |
  |            |                   |             |
  | selfbot    |                   | /play       |
  | voice      |                   | panel       |
  | Go Live    |                   | progress    |
  +-----+------+                   +-----+-------+
        |                                |
        |        HTTP on 127.0.0.1       |
        +<-------------------------------+
        |   play pause resume seek       |
        |   skip stop status             |
        |
  +-----v------+
  |   PLAYER   |
  |            |      megaplay.buzz
  | resolve  --+--->  embed page -> getSources -> master.m3u8
  | proxy      |
  | browser    |      Chromium + hls.js on Xvfb
  |  or ffmpeg |           |
  | capture    |      x11grab + PulseAudio null sink
  |            |           |
  | watchdog   |      ffmpeg -> 720p30 H.264 + Opus, NUT out
  +-----+------+
        |
        v
  @dank074/discord-video-stream -> Discord voice
```

Folders:

- `shared/` protocol, panel layout, time parsing, the megaplay client, progress
  storage. No Discord and no video in here, which is why it is fully unit
  testable.
- `player/` resolves an episode, proxies the HLS, plays it, captures the screen,
  watches for a frozen picture. Knows nothing about Discord.
- `streamer/` the selfbot. Owns the IPC server and the voice connection.
- `controller/` the application bot. Owns the command, the panel and the
  progress records.

The separation is enforced by what each folder imports, not by convention:
`controller/` never imports `player/`, and `streamer/` has no command handlers.

## Why it is built this way

One line per decision that is not obvious.

- **Two processes, not one.** Discord video streaming needs a user token, and
  an application bot cannot do it. Keeping them apart means the rule-breaking
  half is small, isolated and easy to stop using.
- **IPC over localhost HTTP rather than a library.** Both halves restart
  independently, and the traffic is readable with `curl` when something goes
  wrong.
- **A loopback bind plus a bearer token.** Loopback already limits who can
  connect; the token stops other processes on the same box from driving it.
- **Chromium on Xvfb rather than a headless decode.** Go Live streams a screen,
  so the simplest correct thing is to render a real page and capture it. It also
  means the captions, the black bars and the fullscreen behaviour are whatever
  a browser would do, not a reimplementation of them.
- **An ffmpeg-only fallback.** A VPS without a working display can still
  stream, with captions burned in by the `subtitles` filter and `-ss` for
  resume.
- **A local HLS proxy.** It restamps the lying `Content-Type`, gives paths real
  extensions so FFmpeg's demuxer accepts them, and keeps one place to add the
  `Referer` header.
- **Components V2 with no embed.** The panel is a single Container with no
  accent colour, as specified.
- **Progress keyed per user, per episode.** Two people watching the same episode
  should not share a resume point.
- **The engine stops itself when an episode ends.** The controller watches for
  the transition into idle, which is what makes autoplay work.

## Testing

One command runs everything:

```bash
npm test
```

Or individually:

```bash
npm run test:unit
npm run test:integration
npm run test:e2e
npm run test:chaos
SOAK_MINUTES=30 npm run test:soak
```

### Results on this machine

Debian 13, 2 CPUs, 2 GB RAM, ffmpeg 7.1.5, Node 20.20.2.

| Suite | Tests | Result | What it actually exercises |
| --- | --- | --- | --- |
| unit | 85 | pass | Time parsing, URL building, panel layout snapshots, permissions, progress storage, panel refresh coalescing, display slot allocation, log redaction |
| integration | 13 | pass | A mock megaplay server that reproduces the real API's shapes, including the 200-with-error-page 404 and the lying content types. Sub fallback, mirror retry, empty source lists, the HLS proxy feeding FFmpeg |
| e2e | 23 | pass | Real Chromium on Xvfb playing a local HLS fixture. Frames verified to change, seek lands within a second, pause freezes frames, skip jumps correctly, capture verified as 720p H.264 with Opus audio and a measured 6.5 ms A/V offset |
| chaos | 15 | pass | Killing Chromium mid-stream, killing the encoder, a server that never answers, a server that drops connections, bad and missing IPC tokens, oversized and malformed bodies, 404 episodes, empty API responses, and a check that no process is left behind |
| soak | 1 | pass at 30 minutes | 60 samples over half an hour of continuous playback: clock drift 0 s against wall time, heap 7.5 MB rising to 10.7 MB with no runaway growth, no process accumulation, nothing left running at the end |

Total 138 passing. `npm test` runs the first four and takes about four minutes.

The soak defaults to one minute so the full run stays quick. The 30 minute
result above came from `SOAK_MINUTES=30 npm run test:soak`, run on its own so
it had the machine to itself.

### What the tests are not

The integration suite talks to a **mock**, not to megaplay.buzz. The mock was
written from recorded responses and reproduces the awkward parts on purpose,
but a mock cannot catch the API changing. `docs/API.md` has the curl commands
to re-check by hand.

The e2e tests capture a **locally generated** clip, not a real episode. That is
deliberate: it makes the tests hermetic and keeps them off someone else's CDN.

## What has not been verified

Stated plainly, because a claim that was not tested is worse than no claim.

**Needs real credentials, so not tested here:**

- Logging in to Discord with either token.
- Registering the slash command and seeing it in a real server.
- Joining a voice channel and a real person seeing the Go Live stream.
- The panel appearing, and buttons and the seek modal responding in a real
  channel.
- Autoplay advancing to a real next episode.

**Needs a real account, so not tested:**

- Playing a real megaplay episode end to end into Discord. Resolution, the proxy
  and the capture are each tested against recorded shapes and local media, but
  the full chain with a real episode and a real viewer has not been run.

**Untested because it needs keys:**

- TMDB and fanart.tv logo lookups. Without keys the panel falls back to a text
  display, which is what the tests cover.

**Known environment gap:**

- This box runs Node 20.20.2. `@dank074/discord-video-stream` declares
  `engines >=22.4.0`. Everything except the final Discord streaming step runs
  and is tested here; the streaming step is installed and its API was read, but
  it was not exercised.

**Jikan and Kitsu:**

- Jikan v4 timed out when queried, and Kitsu rejects `filter[mal_id]` with a
  400. `shared/src/metadata.js` tries both, guarded, so a missing title or logo
  degrades the panel instead of breaking it.

## Troubleshooting

**`node run.js check` says a token is not valid.** Discord rejected it. A user
token and a bot token are not interchangeable; `DISCORD_USER_TOKEN` takes the
raw user token and `DISCORD_BOT_TOKEN` takes the application bot token.

**The command does not appear.** With `GUILD_ID` set it appears immediately.
Global registration takes up to an hour.

**Black screen but audio works, or nothing at all.** Run
`node scripts/diagnose.js`. It tells you which part of the pipeline is broken
instead of making you guess.

**The streamer says the box is out of memory.** Check for leftovers:

```bash
pgrep -af 'ffmpeg|Xvfb'
```

The streamer sweeps its own leftovers on start and on exit, and it only ever
matches processes it started itself, so it will not touch an unrelated ffmpeg.
If something survived anyway, it means a crash path is missing, which is worth
reporting.

**A dubbed episode plays in Japanese.** That is not a bug in the panel. It
means no dub exists, and the panel line under Status says so.

**Resolution fails with a 403.** The media hosts rotate and expire. Wait a
moment and try again, or add hosts to `MEGAPLAY_MIRRORS`.

## Files

```
run.js                     starts both, or one, or checks the setup
scripts/setup-vps.sh       installs system packages
scripts/diagnose.js        checks the capture pipeline with no token
scripts/run-all-tests.sh   what `npm test` runs
docs/API.md                the megaplay API, as observed
.env.example               every variable, with the reason for each
```
