import test from 'node:test';
import assert from 'node:assert/strict';
import { describePanel, describeMore, describeSeekModal, buildPanel, buildMore, buildSeekModal, languageLabel, accentFor, BTN, COLOR } from '../../shared/src/panel.js';
import { wire } from '../helpers/wire.js';

const BASE = {
  title: 'One Piece',
  episode: 1,
  searchUrl: 'https://www.google.com/search?q=One%20Piece%20episode%201',
  logoUrl: 'https://example.com/logo.png',
  position: 42,
  duration: 1440,
  audio: 'dub',
  captions: true,
  state: 'playing',
  error: null,
  volume: 1,
};

test('the main panel is a heading, bold lines, three transport buttons and more', () => {
  const d = describePanel(BASE);
  assert.equal(d.accentColor, COLOR.playing);
  assert.equal(d.header, null);
  assert.equal(d.footer, null);
  assert.equal(d.children[0].kind, 'section');
  assert.equal(d.children[0].accessory.url, BASE.logoUrl);
  assert.equal(d.children[0].components[0].content, '## [One Piece - Episode 1](https://www.google.com/search?q=One%20Piece%20episode%201)');
  const text = d.children[1].content;
  assert.match(text, /^\*\*Duration\*\* 00:42 \/ 24:00/);
  assert.match(text, /\*\*Language\*\* English \(Dub\)/);
  assert.match(text, /\*\*Captions\*\* On/);
  assert.doesNotMatch(text, /Status/);
  assert.deepEqual(d.children[3].components.map((b) => b.label), ['\u2190', 'Pause', '\u2192']);
  assert.deepEqual(d.children[3].components.map((b) => b.id), [BTN.BACK10, BTN.TOGGLE, BTN.FWD10]);
  assert.equal(d.children[4].components[0].id, BTN.MORE);
  assert.equal(d.children[4].components[0].label, 'More options');
});

test('playing is green and stopped is red', () => {
  assert.equal(accentFor('playing'), COLOR.playing);
  assert.equal(accentFor('paused'), COLOR.paused);
  assert.equal(describePanel({ ...BASE, state: 'idle' }).accentColor, COLOR.stopped);
  assert.equal(describePanel({ ...BASE, state: 'error', error: 'no dub' }).accentColor, COLOR.stopped);
  assert.match(describePanel({ ...BASE, state: 'error', error: 'no dub' }).children[1].content, /\*\*Error\*\* no dub/);
});

test('the real container carries the accent, the heading and the three buttons', async () => {
  const json = wire((await buildPanel(BASE)).toJSON());
  assert.equal(json.type, 17);
  assert.equal(json.accent_color, COLOR.playing);
  assert.equal(json.components[0].type, 9);
  assert.equal(json.components[0].accessory.type, 11);
  assert.equal(json.components[0].accessory.media.url, BASE.logoUrl);
  assert.equal(json.components[0].components[0].content.startsWith('## [One Piece'), true);
  const rows = json.components.filter((c) => c.type === 1);
  assert.equal(rows.length, 2);
  assert.deepEqual(rows[0].components.map((b) => b.label), ['\u2190', 'Pause', '\u2192']);
  assert.equal(rows[1].components[0].label, 'More options');
  assert.equal(json.components.some((c) => /Status/.test(c.content || '')), false);
});

test('a missing logo still renders the heading', async () => {
  const json = wire((await buildPanel({ ...BASE, logoUrl: null })).toJSON());
  assert.equal(json.components[0].type, 10);
  assert.match(json.components[0].content, /^## \[One Piece - Episode 1\]/);
});

test('paused flips the center button to Resume', () => {
  const row = describePanel({ ...BASE, state: 'paused' }).children[3];
  assert.equal(row.components[1].label, 'Resume');
  assert.equal(row.components[0].label, '\u2190');
  assert.equal(row.components[2].label, '\u2192');
});

test('more options is buttons for seek, skips, volume up to 300 percent, and stop', async () => {
  const d = describeMore({ ...BASE, volume: 3, autoplay: false });
  assert.match(d.children[0].content, /\*\*Volume\*\* 300%/);
  assert.deepEqual(d.children[1].components.map((b) => b.label), ['Seek', 'Skip intro', 'Skip outro']);
  assert.deepEqual(d.children[2].components.map((b) => b.label), ['50%', '100%', '200%', '300%']);
  assert.equal(d.children[2].components[3].style, 'primary');
  assert.equal(d.children[2].components[1].style, 'secondary');
  const json = wire((await buildMore({ ...BASE, volume: 2 })).toJSON());
  assert.equal(json.type, 17);
  assert.equal(json.components.filter((c) => c.type === 1).length, 3);
  for (const row of json.components.filter((c) => c.type === 1)) {
    assert.ok(row.components.length <= 5);
  }
});

test('language labels distinguish sub from dub', () => {
  assert.equal(languageLabel('dub'), 'English (Dub)');
  assert.equal(languageLabel('sub'), 'Japanese (Sub)');
});

test('seek modal still accepts a prefilled position', async () => {
  assert.equal(describeSeekModal(42).customId, 'panel:seek:modal');
  const json = wire((await buildSeekModal(3723)).toJSON());
  assert.equal(json.custom_id, 'panel:seek:modal');
  assert.equal(json.components[0].components[0].value, '1:02:03');
});
