// STREAMER entry point.
//
// This process is the selfbot half. It has no commands and no user interface.
// All it does is:
//
//   - log a user account in
//   - listen on a loopback port for commands from the controller
//   - run the playback engine (browser or ffmpeg) and push video to Discord
//
// Run it with:  npm run start:streamer

import 'dotenv/config';
import { IpcServer } from './ipc-server.js';
import { DiscordStreamer } from './discord-streamer.js';
import { PlaybackEngine } from '../../player/src/playback-engine.js';
import { installExitGuard, killOrphans } from '../../player/src/process-guard.js';
import { CMD, STATE } from '../../shared/src/ipc-protocol.js';
import { withRetry } from '../../shared/src/retry.js';

const log = (...args) => console.log('[streamer]', ...args);

async function main() {
  installExitGuard(log);

  // Clear out anything a previous run left behind. A crashed streamer orphans
  // its FFmpeg and Xvfb children, and on a small VPS those add up fast enough
  // to stop the next run from starting.
  killOrphans(undefined, log);

  const token = process.env.DISCORD_USER_TOKEN;
  if (!token) {
    console.error('[streamer] DISCORD_USER_TOKEN is not set. Copy .env.example to .env and fill it in.');
    process.exit(1);
  }
  const ipcPort = Number(process.env.IPC_PORT || 8787);
  const ipcToken = process.env.IPC_TOKEN || '';
  const mirrors = (process.env.MEGAPLAY_MIRRORS || '').split(',').map((s) => s.trim()).filter(Boolean);
  if (process.env.PLAYER_BACKEND && process.env.PLAYER_BACKEND !== 'browser') {
    log(`ignoring PLAYER_BACKEND=${process.env.PLAYER_BACKEND}, playback is browser only`);
  }

  const engine = new PlaybackEngine({ mirrors, log });
  const discord = new DiscordStreamer({ userToken: token, log });

  // Voice and stream auto-reconnect: the library raises gateway events, and we
  // additionally re-join on a timer when the connection has gone away.
  let reconnectTimer = null;
  const startReconnectWatcher = () => {
    if (reconnectTimer) return;
    reconnectTimer = setInterval(async () => {
      if (!engine.active || discord.connected) return;
      const req = engine.request;
      if (!req) return;
      log('voice connection lost, rejoining');
      try {
        await withRetry(() => discord.joinVoice(req.guildId, req.channelId), { attempts: 5, baseMs: 1000, maxMs: 15000, signal: undefined });
        await discord.streamTo({ guildId: req.guildId, input: engine.stream });
      } catch (e) {
        log(`reconnect failed: ${e.message}`);
      }
    }, 5000);
    reconnectTimer.unref?.();
  };

  // Login with retries, because a cold network is the usual reason it fails.
  await withRetry(() => discord.login(), {
    attempts: 4,
    baseMs: 1500,
    maxMs: 20000,
    onRetry: ({ attempt, error, waitMs }) => log(`login attempt ${attempt} failed (${error.message}), retrying in ${waitMs}ms`),
  });

  const ipc = new IpcServer({ port: ipcPort, token: ipcToken, log });
  await ipc.start();
    log('ready. playback is browser only');

  /** Currently running stream promise, so stop can cancel it. */
  let streamPromise = null;
  let streamAbort = null;

  ipc.on('command', async (type, body) => {
    switch (type) {
      case CMD.PING:
        return { pong: true, active: engine.active };

      case CMD.STATUS:
        return { status: engine.status(), connected: discord.connected };

      case CMD.PLAY: {
        if (engine.active) {
          const err = new Error('A stream is already running. Stop it first.');
          err.code = 'conflict';
          throw err;
        }
        // Join voice before resolving, so a channel problem is reported early.
        await discord.joinVoice(body.guildId, body.channelId);
        startReconnectWatcher();

        // startAt lets the controller resume an episode part way through.
        const input = await engine.play(body, { startAt: body.startAt || 0 });
        streamAbort = new AbortController();
        // Fire and forget: playStream resolves when the media ends.
        streamPromise = discord
          .streamTo({ guildId: body.guildId, input, signal: streamAbort.signal })
          .then(() => log('media ended'))
          .catch((e) => {
            if (!streamAbort?.signal.aborted) log(`stream error: ${e.message}`);
          });
        return { started: true, status: engine.status() };
      }

      case CMD.PAUSE:
        return { paused: await engine.pause(), status: engine.status() };

      case CMD.RESUME:
        return { resumed: await engine.resume(), status: engine.status() };

      case CMD.SEEK: {
        const to = await engine.seek(Number(body.seconds));
        return { position: to, status: engine.status() };
      }

      case CMD.SKIP: {
        const result = await engine.skip();
        return { ...result, status: engine.status() };
      }

      case CMD.SKIP_INTRO: {
        const result = await engine.skipIntro();
        return { ...result, status: engine.status() };
      }

      case CMD.SKIP_OUTRO: {
        const result = await engine.skipOutro();
        return { ...result, status: engine.status() };
      }

      case CMD.VOLUME: {
        const level = await engine.setVolume(body.level);
        return { level, status: engine.status() };
      }

      case CMD.CAPTIONS: {
        const on = await engine.setCaptions(body.on);
        return { captions: on, status: engine.status() };
      }

      case CMD.STOP: {
        streamAbort?.abort();
        streamAbort = null;
        await discord.stopAll();
        await engine.stop();
        streamPromise = null;
        return { stopped: true, status: engine.status() };
      }

      default:
        throw new Error(`Unhandled command ${type}`);
    }
  });

  // When the engine errors or restarts, the controller finds out on its next
  // status poll, so no push channel is needed.
  engine.on('state', (s) => log(`state -> ${s.state}${s.error ? ` (${s.error})` : ''}`));
  engine.on('restarted', (info) => log(`restarted at ${info.at.toFixed(1)}s, new stream ready`));
  engine.on('ended', () => log('episode reached the end'));

  const shutdown = async (reason) => {
    log(`shutting down (${reason})`);
    try { streamAbort?.abort(); } catch { /* ignore */ }
    await discord.logout().catch(() => {});
    await engine.stop().catch(() => {});
    await ipc.stop().catch(() => {});
    killOrphans(undefined, log);
    process.exit(0);
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

main().catch((err) => {
  console.error('[streamer] fatal:', err?.message);
  killOrphans(undefined, log);
  process.exit(1);
});
